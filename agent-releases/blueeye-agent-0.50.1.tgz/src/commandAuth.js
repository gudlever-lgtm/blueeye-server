'use strict';

const fs = require('fs');
const path = require('path');
const { verifyManifest, purposeOk } = require('./release/verifyManifest');

// Authenticity of a server -> agent COMMAND.
//
// By default a command is trusted because it arrived on the authenticated
// WebSocket: whoever holds that socket can ask the agent to self-update,
// self-delete or install a package. For the privileged commands that puts the
// whole fleet's integrity on the server never being wrong — so those can carry
// an Ed25519 signature made with the same release key the agent already pins for
// signed updates, and the agent checks it before acting.
//
// The field is `commandSignature`, NOT `signature`: on an update command
// `signature` is already taken — it signs the RELEASE MANIFEST, which
// authenticates the payload to install, not the instruction to install it.
//
// The signed payload is the command MINUS `commandSignature` and MINUS `id`.
// `id` is a correlation token the transport stamps on at send time (the agent
// echoes it back on the ack); it carries no authority, and it is assigned after
// the command is built, so it cannot be part of what was signed.
//
// Policy — verifyCommand():
//   signature + pinned key   -> must verify, or the command is refused
//   no signature, lenient    -> allowed (backward compatible with older servers)
//   no signature, strict     -> refused
// Strict mode is BLUEEYE_REQUIRE_SIGNED_COMMANDS, the command-channel twin of
// BLUEEYE_REQUIRE_SIGNED_UPDATES.

// How far a signed command's issuedAt may sit from the agent's clock. Bounds the
// window in which a captured command can be replayed, while tolerating ordinary
// clock skew on an on-prem host.
const MAX_SKEW_MS = 5 * 60 * 1000;

// The exact bytes the server signed: everything except the signature itself and
// the transport correlation id.
function signedPayload(command) {
  const payload = {};
  for (const [k, v] of Object.entries(command || {})) {
    if (k === 'commandSignature' || k === 'id') continue;
    payload[k] = v;
  }
  return payload;
}

const TRUTHY = /^(1|true|yes|on)$/i;
const FALSY = /^(0|false|no|off)$/i;

// Does this agent REQUIRE signed privileged commands?
//
// It is a RATCHET, not a fixed policy: leniency is dropped the first time this
// server proves it can sign, and never returns.
//
//   the server has signed before -> require signatures from now on
//   the vendor chain is in force -> require signatures (same latch)
//   neither, yet                 -> accept unsigned, as older agents always did
//
// The first version of this derived the answer from "is a key pinned", and that
// was wrong in a way worth writing down. Pinning a key says the agent can CHECK
// a signature; it says nothing about whether its server can MAKE one. A server
// whose signing key was lost or cannot be decrypted pins a key on every agent it
// installed and can sign nothing — so the rule turned "updates are refused"
// into "update, delete and install-tool are ALL refused", on the entire fleet,
// with the only fix behind the host access these hosts do not have. A security
// default that bricks the recovery path is not a security default.
//
// What the ratchet gives instead: in a healthy deployment the very first signed
// command latches the agent, and an unsigned one is refused from then on — an
// attacker holding the socket cannot un-ring that bell. In a deployment that
// cannot sign yet, management keeps working while the operator fixes the key,
// which is the only state from which it CAN be fixed.
//
// Both directions stay overridable: BLUEEYE_REQUIRE_SIGNED_COMMANDS=1 forces it
// on (failing closed even where nothing can sign), =0 turns it off.
function requireSignedCommands(env = process.env, { signedBefore = false } = {}) {
  const raw = String(env.BLUEEYE_REQUIRE_SIGNED_COMMANDS || '').trim();
  if (TRUTHY.test(raw)) return true;
  if (FALSY.test(raw)) return false;
  return !!signedBefore;
}

// REKEY IS DIFFERENT, and is strict by default.
//
// The lenient default above is a deliberate backward-compatibility choice for
// update/delete/install-tool: an older server cannot sign, and those commands
// are bounded — `delete` removes the agent, which is loud and visible in the
// fleet list, and `update` installs a release whose own manifest signature is
// still checked separately.
//
// `rekey` is not bounded in the same way. It replaces the trust anchor, and
// every signature check AFTERWARDS is made against the new key. Accepting an
// unsigned one turns a single moment of access to the socket into permanent,
// SILENT code execution on the host: the attacker rekeys to their own key, and
// from then on their releases verify. That is a qualitatively different thing
// from deleting an agent somebody will notice is gone.
//
// So: when this agent already trusts a key, a rekey must be signed WITH THAT
// KEY — which is exactly what a legitimate rotation looks like, and what the
// server does automatically whenever it can sign (services/commandSigner.js).
//
// The cost, stated plainly: this closes the recover-a-fleet-whose-server-lost-
// its-signing-key path, because that is the one case where the server cannot
// produce the required signature. That path is not gone, it now needs the level
// of authority it always should have — someone with access to the host sets
// BLUEEYE_ALLOW_UNSIGNED_REKEY=1 in the unit (or re-runs the installer). Being
// able to re-anchor a host's trust remotely, with no signature and no host
// access, was never a smaller privilege than root on that host.
//
// A fresh install with NO key pinned is unaffected: there is nothing to
// downgrade, the anchor arrived by trust-on-first-use anyway, and refusing here
// would break provisioning for no gain.
function allowUnsignedRekey(env = process.env) {
  return TRUTHY.test(String(env.BLUEEYE_ALLOW_UNSIGNED_REKEY || '').trim());
}

// Remembers the commandIds this agent has already accepted, so a captured
// signed command cannot be replayed against the SAME agent inside its validity
// window (the agentId binding only stops replay against the REST of the fleet).
// Ids are forgotten once they can no longer be valid, which keeps the set the
// size of "privileged commands in the last few minutes" — single digits.
//
// Backed by a file when one is given (the runtime gives it the state dir beside
// the pinned key), so the ids survive a restart — a captured command whose
// validity window outlives a restart is exactly the case an in-memory set
// missed. Without a file the guard is memory-only, which is what the tests and
// a read-only install get.
//
// A write that fails does NOT refuse the command: the signature verified and
// the id is fresh, so refusing would turn a full disk into a fleet that cannot
// be managed. The guard degrades to in-memory for that command and says so.
function createReplayGuard({ now = () => Date.now(), file = null, fsImpl = fs, onWarn = null } = {}) {
  const seen = new Map(); // commandId -> ms after which it can no longer be valid
  let loaded = false;

  function prune(t) {
    for (const [id, expiry] of seen) if (expiry <= t) seen.delete(id);
  }

  // Read once, lazily — an agent that never gets a privileged command never
  // touches the disk. An unreadable or corrupt file reads as "nothing seen",
  // the same safe direction the trust state takes: it can let a replay through
  // in the window after a restart, which is where we already were, and it can
  // never lock a legitimate command out.
  function load(t) {
    loaded = true;
    if (!file) return;
    try {
      const raw = JSON.parse(fsImpl.readFileSync(file, 'utf8'));
      const ids = raw && typeof raw === 'object' ? raw.ids : null;
      if (!ids || typeof ids !== 'object') return;
      for (const [id, expiry] of Object.entries(ids)) {
        const ms = Number(expiry);
        if (typeof id === 'string' && id && Number.isFinite(ms) && ms > t) seen.set(id, ms);
      }
    } catch { /* nothing seen */ }
  }

  function persist() {
    if (!file) return;
    const body = JSON.stringify({ ids: Object.fromEntries(seen) });
    try {
      fsImpl.mkdirSync(path.dirname(file), { recursive: true });
      const tmp = `${file}.${process.pid}.tmp`;
      fsImpl.writeFileSync(tmp, `${body}\n`, { mode: 0o600 });
      fsImpl.renameSync(tmp, file);
    } catch (e) {
      // Said once per failure, not swallowed: an agent whose guard is only
      // in-memory should be visible in its log.
      if (onWarn) onWarn(`command replay guard could not be persisted (${e.message}); replay protection is in-memory until this is fixed`);
    }
  }

  // True the FIRST time an id is seen, false every time after. Recording and
  // checking are one step on purpose: two steps is how a check-then-use race
  // lets a replay through.
  function accept(commandId, notValidAfterMs) {
    const t = now();
    if (!loaded) load(t);
    prune(t);
    if (seen.has(commandId)) return false;
    seen.set(commandId, notValidAfterMs);
    persist();
    return true;
  }

  return { accept, get size() { return seen.size; } };
}

// Returns { ok: true, signed } or { ok: false, reason }. Never throws — the
// caller turns a refusal into a declined command, not a crash.
function verifyCommand(command, {
  publicKey = '',
  agentId = null,
  strict = false,
  // True for the one command that replaces the trust anchor. See
  // allowUnsignedRekey() above for why it does not follow the lenient default.
  isRekey = false,
  allowUnsignedRekeyOverride = allowUnsignedRekey(),
  now = () => Date.now(),
  maxSkewMs = MAX_SKEW_MS,
  // The agent's replay guard (createReplayGuard above). Without one a signed
  // command is still checked for freshness, but not for having been seen
  // before — so the runtime always passes one.
  replayGuard = null,
} = {}) {
  const signature = command && command.commandSignature;
  if (!signature) {
    // The host-side break-glass is checked BEFORE strict mode, not after.
    // BLUEEYE_ALLOW_UNSIGNED_REKEY is set by someone with access to this host,
    // for the one case where the server cannot sign anything at all — and strict
    // mode is now the default wherever a key is pinned, so checking it second
    // would silently take the escape hatch away exactly when it is needed.
    if (isRekey && allowUnsignedRekeyOverride) return { ok: true, signed: false };
    if (strict) return { ok: false, reason: 'refused: unsigned command (this agent requires signed commands)' };
    if (isRekey && publicKey && !allowUnsignedRekeyOverride) {
      return {
        ok: false,
        reason: 'refused: an unsigned rekey cannot replace a trust anchor this agent already holds. '
          + 'A legitimate rotation is signed with the key being replaced. To re-anchor a host whose '
          + 'server can no longer sign, set BLUEEYE_ALLOW_UNSIGNED_REKEY=1 on the host and restart, '
          + 'or re-run the installer.',
      };
    }
    return { ok: true, signed: false };
  }
  // A signature we cannot check is worse than none: fail closed rather than
  // accept it because it "looks signed".
  if (!publicKey) return { ok: false, reason: 'refused: command is signed but no release public key is configured' };
  const payload = signedPayload(command);
  if (!verifyManifest(payload, signature, publicKey)) {
    return { ok: false, reason: 'refused: command signature verification failed' };
  }
  // What the signature is FOR. Required here: this agent already refuses a
  // signed command with no commandId, so a server new enough to sign is new
  // enough to stamp both — and a signature the server made over a release
  // manifest must not be presentable as an instruction to this host.
  if (!purposeOk(payload, 'command', { required: true })) {
    return {
      ok: false,
      reason: `refused: this signature is not for a command (purpose: ${payload.purpose == null ? 'none' : String(payload.purpose)})`,
    };
  }
  // A valid signature over a payload naming neither an agent nor a time is
  // replayable at every other agent, for ever. Require both.
  if (command.agentId == null) return { ok: false, reason: 'refused: signed command names no agent' };
  if (agentId != null && String(command.agentId) !== String(agentId)) {
    return { ok: false, reason: 'refused: command was signed for a different agent' };
  }
  const issuedAt = Date.parse(command.issuedAt || '');
  if (!Number.isFinite(issuedAt)) return { ok: false, reason: 'refused: signed command has no valid issuedAt' };
  if (Math.abs(now() - issuedAt) > maxSkewMs) {
    return { ok: false, reason: 'refused: signed command is outside the accepted time window (replay?)' };
  }
  // The server states its own expiry rather than leaving the lifetime to
  // whatever skew window this agent happens to allow. Checked IN ADDITION to
  // the skew window, never instead of it: the field is inside the signature, so
  // a long expiresAt is the server's choice to make, but it cannot stretch the
  // window past the agent's own tolerance.
  if (command.expiresAt != null) {
    const expiresAt = Date.parse(command.expiresAt);
    if (!Number.isFinite(expiresAt)) return { ok: false, reason: 'refused: signed command has an unreadable expiresAt' };
    if (now() > expiresAt) return { ok: false, reason: 'refused: signed command has expired' };
  }
  // A signed command with no nonce is replayable against this agent for the
  // length of the window. Required, not tolerated: accepting one would be a
  // silent downgrade of exactly the protection the nonce exists for. A server
  // old enough not to send it is also old enough not to sign at all, and its
  // unsigned commands still follow the lenient/strict policy above.
  if (!command.commandId) {
    return {
      ok: false,
      reason: 'refused: signed command carries no commandId, so a replay of it could not be detected. '
        + 'The server needs an update (it signs commands but does not stamp them with a unique id).',
    };
  }
  if (replayGuard && !replayGuard.accept(String(command.commandId), issuedAt + maxSkewMs)) {
    return { ok: false, reason: 'refused: this command has already been carried out (replay)' };
  }
  return { ok: true, signed: true };
}

module.exports = { verifyCommand, requireSignedCommands, allowUnsignedRekey, createReplayGuard, signedPayload, MAX_SKEW_MS };
