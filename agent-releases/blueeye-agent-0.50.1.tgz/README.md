# blueeye-agent

The **BlueEyes Network Resilience System** agent runs on customer machines and
connects to **blueeye-server**.
It enrolls once with a one-time code, stores an **opaque token** locally,
keeps a **WebSocket** open to the server (status + commands), and submits
**test results** via REST.

Written in Node.

## Dependencies

Open-source / permissive licences only — **no US-cloud SDKs**, no telemetry:

| Component        | Licence | Role                                    |
| ---------------- | ------- | ---------------------------------------- |
| ws               | MIT     | WebSocket client (agent live channel)    |
| Node `fetch`     | —       | HTTP (built-in undici — Node.js project) |
| Node `node:test` | —       | Test runner (development only)           |

`ws` is the only external runtime dependency. HTTP is handled by Node's
built-in `fetch`, so there is no external HTTP SDK.

## Requirements

- Node.js >= 18 (developed and tested on Node 22)
- Linux, macOS or Windows. The one-liner installs a systemd service, a launchd
  daemon or a scheduled task accordingly; the Docker image is 64-bit Linux
  (`linux/amd64` or `linux/arm64`)
- Access to a running `blueeye-server`

## Getting started

```bash
npm install

# 1) Create a config (see config.example.json) with serverUrl + one-time code
cp config.example.json blueeye-agent.config.json
#    Obtain the one-time code from the server:  POST /enrollment-codes (operator/admin)

# 2) Start the agent
npm start
```

On first start the agent enrolls, stores its token, and removes the
one-time code from the config file. Subsequent starts use the stored token and
**skip enrollment**.

### Easiest: one-liner from the server

In the server UI (**Enrollment → Add agent**) a ready-made command is generated
with the code, server address, and checksum already filled in. Run it on the
machine:

```bash
# Linux and macOS
curl -sSL https://<server>/enroll/<CODE>/install.sh | sh
```

On **Windows** the same page gives a PowerShell command instead: it downloads
`/enroll/<CODE>/install.ps1` to `$env:TEMP` and runs it from there (deliberately
not `irm … | iex` — a downloaded script should be on disk where it can be read
before it runs). Run it in an **elevated** PowerShell.

The script fetches the agent **from the server itself** (works in air-gapped
networks too), verifies it, runs `blueeye-agent enroll`, and installs whatever
the host supervises with: a **systemd service** on Linux, a **LaunchDaemon** on
macOS, a **scheduled task** on Windows. You never type the server address
yourself.

### Manual: the `enroll` command

```bash
blueeye-agent enroll --code <CODE> [--server <URL>] [--fingerprint <SHA256>]
```

Exchanges the code for a token and stores it (0600). `--server`/`--fingerprint`
are saved in the config file so the service started afterwards reaches the right
server with **certificate pinning**. If `--server` is omitted, the embedded or
configured URL is used (or `GET /enroll/config`). The command is idempotent:
if a token already exists it does nothing (unless `--force`).

## Install as a Docker container

`install.sh` clones/updates the repo, builds the image, and runs the agent as a
restart-on-boot container. The token lives on a named volume so it is reused
across restarts and upgrades (the one-time code is only used on first start).

```bash
# Clone the repo
git clone https://github.com/gudlever-lgtm/blueeye-agent.git
cd blueeye-agent

# Install + start as a Docker container (Linux: --network host measures host traffic)
BLUEEYE_SERVER_URL=https://server.example \
BLUEEYE_ENROLLMENT_CODE=<one-time-code> \
./install.sh
```

Update later with `git pull` and run `./install.sh` again (or run the script from
anywhere — without a checkout it clones the repo itself). Optional env:
`NETWORK_MODE=bridge`, `CONTAINER`, `IMAGE`, `TOKEN_VOLUME`. Manage the container with
`docker logs -f blueeye-agent` / `docker restart blueeye-agent`.

The image is built for a **64-bit** platform. `install.sh` detects the host
architecture automatically (`linux/amd64` or `linux/arm64`); override with `PLATFORM`, e.g.
`PLATFORM=linux/arm64 ./install.sh`. 32-bit hosts are not supported.

## Running as a service

In normal use the agent runs **under a supervisor** so it survives crashes and
reboots — and, under **systemd**, can be updated with one click from the
dashboard. The one-liner installer sets this up for you: it installs either a
**systemd service** or a **Docker container** named `blueeye-agent`.

The underlying start command is:

```bash
npm start          # = node src/index.js (runs in the foreground)
```

Run bare like that, the agent is **unmanaged**: nothing restarts it, and the
dashboard's one-click update can't reach it (it reports `managed: unmanaged`).
Fine for a quick test — but for a real install, run it as a service.

**systemd (Node install).** Write a unit so the agent runs as a managed service.
The key line is `BLUEEYE_RUNTIME=systemd`, which makes the agent report itself as
managed so the dashboard **Update** button works:

```ini
# /etc/systemd/system/blueeye-agent.service
[Unit]
Description=BlueEyes monitoring agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/blueeye-agent
Environment=BLUEEYE_SERVER_URL=https://server.example
Environment=BLUEEYE_TOKEN_PATH=/opt/blueeye-agent/token
Environment=BLUEEYE_RUNTIME=systemd
# Environment=BLUEEYE_SERVER_CERT_FINGERPRINT=<sha256>   # optional: pin the server's TLS cert (https)
ExecStart=/usr/bin/npm start
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now blueeye-agent     # start now + on every boot
systemctl status blueeye-agent                # is it running?
journalctl -u blueeye-agent -f                # follow logs
```

> `ExecStart` runs `npm start` (i.e. `node src/index.js`). If `npm` isn't on
> systemd's `PATH`, use the absolute path from `command -v npm` — or point
> `ExecStart` straight at Node, as the bundled installer does:
> `ExecStart=/usr/bin/node /opt/blueeye-agent/src/index.js`.

**macOS (launchd).** The one-liner installs a LaunchDaemon labelled
`com.blueeye.agent` at `/Library/LaunchDaemons/com.blueeye.agent.plist`, with
`KeepAlive` (so it comes back) and `BLUEEYE_RUNTIME=launchd` in its
`EnvironmentVariables`. That tag is what makes the agent report `managed:
launchd`, so one-click updates from the dashboard work the same as on systemd.

```bash
sudo launchctl print system/com.blueeye.agent     # is it loaded, and what state
sudo launchctl kickstart -k system/com.blueeye.agent   # restart it
```

**Windows (scheduled task).** `install.ps1` installs Node + the agent and
registers a scheduled task that runs it as `SYSTEM` at boot, restarting on
failure — the dependency-free equivalent of the systemd unit. A scheduled task
is not a service, so the launcher sets `BLUEEYE_RUNTIME=unmanaged` and the agent
**declines a pushed update**, which is the safe answer: nothing there would stop
and start it cleanly on the server's behalf. Updating it is one command on the
host instead — see below. stdout and stderr go to `agent.log` in the log
directory, because a task running as SYSTEM has no console and "installed but
not connected" otherwise has no indicator.

```powershell
Get-ScheduledTask -TaskName blueeye-agent | Select-Object State
Stop-ScheduledTask -TaskName blueeye-agent; Start-ScheduledTask -TaskName blueeye-agent
```

> Running the agent as a **real** Windows service (NSSM, `sc.exe`, or any
> wrapper) is supported and pushable: set `BLUEEYE_RUNTIME=windows-service` in
> its environment, and the server restarts it with a detached stop+start after
> swapping the code. A Windows service cannot be detected from the environment —
> the process looks like any other — so without that variable the agent reports
> `unmanaged` and declines.

**Docker.** `./install.sh` already runs the container with `--restart
unless-stopped`, so it returns after a reboot. It reports `managed: docker` —
update it by rebuilding on the host (see below), not from the dashboard.

## Updating an agent

Updates **reuse the stored token** (the Docker volume, or
`/opt/blueeye-agent/token`), so you never re-enroll. Which path you use depends
on how the agent is supervised — `capabilities.managed` decides, not the
platform. Read it in the dashboard under **Fleet → the agent → ⋯ → Ping** (the
toast shows `managed`), or on the host (`docker ps` /
`systemctl status blueeye-agent`).

`systemd`, `launchd` and `windows-service` agents are **pushed to**; `docker` and
`unmanaged` ones are not, because nothing on those hosts would restart the agent
onto new code. Note which side Windows falls on: an agent installed by
`install.ps1` runs under a **scheduled task** and reports `unmanaged`, so it is
updated with a command on the host (below) rather than a push. Only an agent run
as a genuine Windows service, with `BLUEEYE_RUNTIME=windows-service`, is pushed
to.

**Service-managed (systemd / launchd / a real Windows service) — easiest is the
dashboard**: **Fleet → the agent → Update** (the version row in the drawer
carries the action), or **Settings → Updates** for the fleet. What it pushes is
the **signed release**: the agent downloads `/enroll/agent-release.tgz` asking
for the bytes verbatim (`Accept-Encoding: identity` — a proxy that re-encodes an
already-compressed release is what used to produce an unexplainable checksum
mismatch), verifies the Ed25519 signature over the release manifest plus the
sha256 and the version, and only then swaps and restarts. An agent that has
pinned a release key **refuses an unsigned update outright**, so a downgrade to
the unsigned source bundle is not something an attacker can ask for.

The source bundle below is the **fallback** path, for a server with no signed
release. Verify it against the server's published `X-Content-SHA256` header
before extracting — the source endpoint is public (no token needed) and HTTPS
already protects the transfer, but the checksum guards against a
truncated/tampered bundle, mirroring the installer:

```bash
# download the bundle + capture the server's published checksum (response header)
curl -fsSL -D /tmp/agent.hdr https://<server>/enroll/agent-source.tgz -o /tmp/agent.tgz
expected=$(awk 'tolower($1)=="x-content-sha256:"{print $2}' /tmp/agent.hdr | tr -d '\r')
actual=$(sha256sum /tmp/agent.tgz | awk '{print $1}')
[ "$expected" = "$actual" ] || { echo "checksum mismatch — aborting"; exit 1; }

sudo tar -xzf /tmp/agent.tgz -C /opt/blueeye-agent
cd /opt/blueeye-agent && sudo npm ci --omit=dev
sudo systemctl restart blueeye-agent
```

**Docker — rebuild on the host** (from the checkout you installed from; no
enrollment code needed):

```bash
cd /path/to/blueeye-agent && git pull --ff-only
BLUEEYE_SERVER_URL=https://<server> ./install.sh
```

**Windows (scheduled task) — one command on the host.** The dashboard's update
button on such an agent hands you the command instead of pushing: it updates the
installed agent **in place**, carries no enrollment code (so the host keeps its
token and its identity — it can never create a second agent), and refuses a
machine with no agent. Run it in an elevated PowerShell; the agent stops for a
few seconds while its code is replaced, then reconnects on the new version.

**Unmanaged (bare `npm start`)** — nothing restarts it for you; update the
source and restart it yourself:

```bash
cd /path/to/blueeye-agent && git pull --ff-only
npm install --omit=dev        # only if dependencies changed
# stop the running process, then:
npm start
```

### Agents that are not connected when you click

A push needs a live socket, and a host that is online for ten minutes a day
never has one when somebody is looking at the dashboard. Three things cover it,
and none of them is on by default beyond the first:

- **The update is queued.** Updating an agent that is offline is accepted rather
  than refused, and the command is delivered the moment that agent next dials
  in. Clicking Update twice leaves one queued command with the newest target,
  and a queued update expires (24 h by default) instead of installing a version
  two releases old on a host that comes back next month.
- **A fleet rollout** (**Settings → Updates**) moves the agents that are
  actually behind, one batch at a time, with an audit row per agent. Run it with
  a batch of one as a canary first.
- **The agent asks for its own update.** With **Settings → Agents → Automatic
  agent updates** on (off by default), an agent that reads its config and finds
  itself behind asks the server for the update, inside a maintenance window it
  evaluates in **its own local time** (`src/updateWindow.js`, byte-identical to
  the server's copy — a fleet across three time zones cannot have `02:00`
  decided centrally). The server re-checks everything the agent claimed and
  rate-limits it. A single host opts out with `BLUEEYE_AUTO_UPDATE=0`
  (`autoUpdate: false` in the config file).

> The dashboard Update and the `agent-source.tgz` paths install **whatever the
> server currently publishes** (its `AGENT_SOURCE_DIR`). After bumping the agent
> on the server host, refresh it with **Settings → Updates → Reload agent
> source** (no server restart). The `git pull` paths take whatever is on the
> branch you pull. After it restarts, the agent reports its new version on
> reconnect, and the dashboard version line updates.

## Uninstalling

Easiest — a one-liner from the server (mirrors install):

```bash
# Linux and macOS
curl -sSL https://<server>/enroll/uninstall.sh | sudo sh            # warns, then asks y/N
curl -sSL https://<server>/enroll/uninstall.sh | sudo sh -s -- --purge   # pass flags after --
```

On **Windows** it is `/enroll/uninstall.ps1`, downloaded and run from an elevated
PowerShell the same way as the installer — a Windows host is never handed a bash
one-liner. It removes the scheduled task, the install directory, the state
directory (with the token) and the logs, and it is idempotent: a missing task or
directory is not an error. It honours the same `BLUEEYE_INSTALL_DIR` /
`BLUEEYE_STATE_DIR` / `BLUEEYE_LOG_DIR` overrides as the installer.

`uninstall.sh` is also shipped **with the agent** — the installer drops it in the
install directory, so it's already on the machine:

```bash
sudo sh /opt/blueeye-agent/uninstall.sh            # warns, then asks y/N
sudo sh /opt/blueeye-agent/uninstall.sh --yes      # no prompt
sudo sh /opt/blueeye-agent/uninstall.sh --purge    # also remove the Docker image + token volume
```

It auto-detects how the agent was installed and removes it accordingly:

- **Node install** — stops + disables the `blueeye-agent` systemd service and deletes the unit.
- **Docker install** — stops + removes the `blueeye-agent` container (`--purge` also drops the image and the `blueeye-agent-data` volume).
- Removes the install directory `/opt/blueeye-agent` (including the stored token).

It **warns and asks for confirmation first** (skip with `--yes`) and needs `sudo`.
Env overrides: `SERVICE_NAME`, `BLUEEYE_INSTALL_DIR`, `CONTAINER`, `IMAGE`,
`TOKEN_VOLUME`.

> This removes the agent **locally only**. To also remove it from the BlueEyes
> server's list, open the dashboard → **Fleet → the agent → ⋯ → Delete agent**.

(If you installed from a checkout with the Docker `install.sh`, you can run
`sudo ./uninstall.sh` from that checkout instead.)

## Configuration (file + env)

Configuration is read from a JSON file and can be overridden by environment variables
(order: built-in defaults → config file → env). See
[`config.example.json`](config.example.json) and [`.env.example`](.env.example).

| Field (file)      | Env variable                 | Default                        | Description                         |
| ----------------- | ---------------------------- | ------------------------------ | ----------------------------------- |
| (file path)       | `BLUEEYE_AGENT_CONFIG`       | `./blueeye-agent.config.json`  | Path to the JSON config             |
| `serverUrl`       | `BLUEEYE_SERVER_URL`         | `http://localhost:3000`        | blueeye-server URL                  |
| `enrollmentCode`  | `BLUEEYE_ENROLLMENT_CODE`    | (none)                         | One-time code — first start only    |
| `serverUrls`      | `BLUEEYE_SERVER_URLS`        | (none)                         | Extra ways in to the SAME server, tried in order when a connection cannot be established. Comma/space separated |
| `serverCertFingerprint` | `BLUEEYE_SERVER_CERT_FINGERPRINT` | (none)              | SHA-256 of the server's TLS cert — pinned for https. Several may be listed (comma separated), which is how a certificate is RENEWED without locking pinned agents out |
| `serverCertFingerprints` | `BLUEEYE_SERVER_CERT_FINGERPRINTS` | (none)             | The same pin as a LIST (comma/space separated). Add the next certificate's fingerprint BEFORE a renewal: any one of them may match, so a rotation does not lock every pinned agent out of the only channel that could fix it |
| `tokenPath`       | `BLUEEYE_TOKEN_PATH`         | `<agent-dir>/.blueeye-agent/token` | Where the token is stored (0600) — relative to the agent's own directory, not cwd |
| `heartbeatMs`     | `BLUEEYE_HEARTBEAT_MS`       | `15000`                        | Heartbeat message interval          |
| `reconnectBaseMs` | `BLUEEYE_RECONNECT_BASE_MS`  | `1000`                         | Backoff base for reconnect          |
| `reconnectMaxMs`  | `BLUEEYE_RECONNECT_MAX_MS`   | `30000`                        | Backoff ceiling                     |
| `staleConnectionMs` | `BLUEEYE_STALE_CONNECTION_MS` | `3 × heartbeat` (min 30 s)  | Nothing heard back on an open socket for this long = dead, re-dial. `0` disables |
| `socketKeepAliveMs` | `BLUEEYE_SOCKET_KEEPALIVE_MS` | `30000`                    | TCP keepalive on the WebSocket socket. `0` disables |
| `authRetryMs`     | `BLUEEYE_AUTH_RETRY_MS`      | `900000`                       | How long to wait before re-dialling after the server refused the token (401). Never re-enrolls. `0` = the old behaviour, exit and stay down |
| `resultSpoolMax`  | `BLUEEYE_RESULT_SPOOL_MAX`   | `240`                          | Measurements the server could not take are held and re-sent, oldest dropped past this. `0` disables |
| `autoUpdate`      | `BLUEEYE_AUTO_UPDATE`        | `true`                         | Local opt-out from the server's auto-update policy (which is off by default) |
| `probeIntervalMs` | `BLUEEYE_PROBE_INTERVAL_MS`  | `60000`                        | Scheduled probes — `0` disables     |
| `probeCount`      | `BLUEEYE_PROBE_COUNT`        | `3`                            | Attempts per scheduled probe        |
| `probeGateway`    | `BLUEEYE_PROBE_GATEWAY`      | `true`                         | Auto-ping default gateway           |
| `probeDns`        | `BLUEEYE_PROBE_DNS`          | `true`                         | Auto-ping DNS servers (resolv.conf) |
| `probeTargets`    | `BLUEEYE_PROBE_TARGETS`      | (none)                         | Extra targets, e.g. `ping:1.1.1.1,tcp:host:443` |

> **Scheduled probes:** by default the agent runs a small set of reachability
> probes every 60 seconds — the auto-discovered default gateway + DNS servers
> (`/etc/resolv.conf`) plus any `probeTargets` — and submits them to the server, so
> fleet health is populated without manual runs. Metadata only (target + timings),
> never packet contents. Set `BLUEEYE_PROBE_INTERVAL_MS=0` to disable it.

> If the one-time code is provided via env, the agent cannot remove it from there —
> remove it yourself after the first start. (The agent won't re-enroll anyway as long
> as a stored token exists.)

## Enrollment (first start)

1. The agent gathers `hostname`, `platform`, `arch`.
2. `POST /agents/enroll { code, hostname, platform, arch }`.
3. The returned token is stored locally in a file with **restrictive permissions
   (0600)**, and `enrollmentCode` is removed from the config file.
4. If the code is rejected (invalid/used/expired → `401`/`410`), the agent fails
   **hard** and does **not** retry automatically.

## Operation

- Opens a WebSocket to `/ws/agent` with the token in the `Authorization: Bearer` header.
- Sends a periodic heartbeat so the server keeps `last_seen` fresh.
- Listens for server commands. A **run-test** command (e.g.
  `{ type: "command", command: { name: "run-test", intervalMs: 1000 } }`) causes
  the agent to **measure network traffic** and submit the result.
- **Traffic sources** — the agent can measure traffic in two ways, and **the
  server selects which one per agent** (matched by agent ID via the token):
  - `proc` ([`src/trafficMonitor.js`](src/trafficMonitor.js)): reads
    `/proc/net/dev` twice `intervalMs` apart, computing per-interface rx/tx bytes
    and rates. Run the container with `network_mode: host` to measure the host's
    full traffic (otherwise only the container's own interfaces are measured).
  - `snmp` ([`src/snmpMonitor.js`](src/snmpMonitor.js)): polls a Cisco device's
    IF-MIB high-capacity octet counters (ifHCInOctets/ifHCOutOctets) over SNMP —
    useful when the agent runs alongside the device, or on IOS without `/proc`.
    Requires the optional `net-snmp` dependency: `npm install net-snmp` (kept out
    of the agent's single-dependency default footprint). Until it is installed the
    agent reports `snmp` under `unavailable` in its capabilities (`net-snmp not
    installed`), so the dashboard explains why SNMP isn't offered rather than the
    source silently never appearing.
- **Capabilities + config:** on start the agent reports its capabilities
  (`{ sources: [...], unavailable: { ... } }`) to `POST /agents/me/capabilities`
  and fetches its assigned source from `GET /agents/me/config`. It re-fetches the
  config on every (re)connection, every 5 minutes (`BLUEEYE_CONFIG_REFRESH_MS`) and
  before a "Poll now", so dashboard changes take effect without a reconnect. Both
  sources produce the same result format, so the server/dashboard treats them
  uniformly.
- **Continuous reporting:** independently of server commands, the agent measures
  traffic and submits the result on a fixed interval
  (`BLUEEYE_REPORT_INTERVAL_MS`, default 60s; `0` disables it). This is how the
  server receives continuous data without anyone pressing "Run test".
- Submits results via `POST /agents/results { results: [...] }` with a
  Bearer token.
- **Reconnects** on a lost connection with exponential backoff (+ jitter).
- **Hard failure** if the token is rejected (`401` at WS handshake or on
  results-POST): the agent logs the error and stops — it does **not** re-enroll
  automatically.

Two separate security boundaries: the agent's token is used **only** against
agent endpoints (WS + `/agents/results`). It is not a user JWT.

## Project structure

See [`codemap.md`](codemap.md) for an up-to-date map of the source code —
architecture, modules, data flow, traffic sources (proc/snmp/netflow/sflow),
probes, server API, and test structure.

## Tests

```bash
npm test
```

Tests cover: config merging and one-time code clearing, token storage with
`0600` permissions, command recognition, backoff, and **integration tests against
a running server**: enroll flow, WS connect (valid/invalid token), result
submission, and reconnect.

> The integration tests run against a contract-faithful stub server
> ([`test-support/fakeServer.js`](test-support/fakeServer.js)) with exactly the
> same endpoints as `blueeye-server` (`/agents/enroll`, `/ws/agent`,
> `/agents/results`). The real server requires MySQL; the stub makes the tests
> self-contained and fast without deviating from the contract.

### Pre-build gate

`scripts/gate.sh` is the pre-build gate: it runs `test/gate/security.test.js`,
`test/gate/ui.test.js` and `test/gate/validation.test.js`, then the full suite, and
exits non-zero if anything fails. It is wired into Claude Code (`.claude/settings.json`
PreToolUse hook on `git push`), the tracked git `pre-push` hook and the `gate`
GitHub Actions workflow, so every branch build has passed it. Cached per commit +
worktree state; `--force` re-runs, `BLUEEYE_SKIP_GATE=1` bypasses (emergency only).
