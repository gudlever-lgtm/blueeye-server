'use strict';

const { EventEmitter } = require('events');
const { createAgentClient } = require('./agentClient');
const { createApiClient } = require('./apiClient');
const { isRunTestCommand, isRunProbeCommand, isPingCommand, isUpdateCommand, isSpeedtestCommand, isDiagnoseCommand, isDeleteCommand, isInstallToolCommand, isEvidenceCommand, isRunDiscoveryCommand, isRekeyCommand, isPollSnmpCommand, isBurstCommand, isStopBurstCommand, isRunTransactionCommand, transactionIdOf } = require('./command');
const { createScanner, DiscoveryScopeError } = require('./discovery/scanner');
const { collectLocalCidrs } = require('./localIps');
const { createEvidenceCollector } = require('./evidenceCollector');
const { verifyManifest, purposeOk } = require('./release/verifyManifest');
const fs = require('fs');
const { createSelfUpdater } = require('./selfUpdate');
const { verifyCommand, requireSignedCommands, createReplayGuard, allowUnsignedRekey: allowUnsignedRekeyEnv } = require('./commandAuth');
const { createSelfDeleter } = require('./selfDelete');
const { createToolInstaller } = require('./toolInstaller');
const { createActionLog } = require('./actionLog');
const { resolveReleasePublicKey } = require('./release/publicKey');
const keyStore = require('./release/keyStore');
const releaseGuard = require('./release/releaseGuard');
const { createResultSpool } = require('./resultSpool');
const { isWithinWindow } = require('./updateWindow');
const { isNewer: isNewerVersion } = require('./version');
const { verifyTrustProof } = require('./license/trustProof');
const { runSpeedtest } = require('./speedtest');
const { runTest } = require('./testRunner');
const { fitResult, describeTrim } = require('./resultBudget');
const { runProbe } = require('./probes');
const { resolveProbeTargets } = require('./probes/targets');
const { createSampler } = require('./monitor');
const { createHsflowdManager } = require('./sflow/hsflowd');
const { detectCapabilities, isSelfUpdatable } = require('./capabilities');
const { collectNicInfo } = require('./nicInfo');
const { collectConnections } = require('./connTable');
const { collectArpTable } = require('./arpTable');
const { collectLldp: collectLldpDefault } = require('./lldp');
const dns = require('dns');
const net = require('net');
const { collectLocalIps: collectLocalIpsDefault } = require('./localIps');
const { makePinnedFetch } = require('./httpsClient');
const path = require('path');
const { createSecretStore } = require('./transactions/secretStore');
const { createConfigStore } = require('./transactions/configStore');
const { createResultBuffer } = require('./transactions/buffer');
const { createTransactionManager } = require('./transactions/manager');
const { createSyslogReceiver, parseSenderAllowlist } = require('./syslog/receiver');
const { createSnmpPoller } = require('./snmpPoller');
const { createTrapReceiver } = require('./traps/receiver');
const { createBurstRunner } = require('./burst');
const { createCaptureRunner, detectCaptureSupport } = require('./capture');

// Hard cap on how many targets one scheduled cycle will probe, so a giant
// configured/nameserver list can't turn into a burst.
const MAX_SCHEDULED_TARGETS = 16;

// How long poll-snmp waits for the config re-read before polling with the
// assignment it already has. `config.pollConfigTimeoutMs` overrides it (tests).
const POLL_CONFIG_TIMEOUT_MS = 5000;

// JSON with object keys sorted, so two configs that differ only in key order
// compare equal. Arrays keep their order: a reordered target list is a change.
function stableKey(value) {
  return JSON.stringify(value, (k, v) => (v && typeof v === 'object' && !Array.isArray(v)
    ? Object.keys(v).sort().reduce((o, key) => { o[key] = v[key]; return o; }, {})
    : v));
}

// One-line, human-readable summary of a probe result for the info log.
function describeProbeOutcome(result) {
  if (!result.ok) return 'error';
  if (result.type === 'traceroute') {
    const hops = result.hopCount ?? (result.hops ? result.hops.length : '?');
    return `${hops} hops`;
  }
  return `${result.rttMs ?? '?'} ms`;
}

// Derives the hsflowd exporter options from the monitor config, or null when a
// local exporter isn't requested. A host self-provisions hsflowd only when the
// source is sflow AND `sflow.hsflowd` is set (true, or an options object) — so
// agents that receive sFlow from an external switch are unaffected.
function sflowExporterOptions(mc) {
  if (!mc || mc.source !== 'sflow' || !mc.sflow || !mc.sflow.hsflowd) return null;
  const h = typeof mc.sflow.hsflowd === 'object' ? mc.sflow.hsflowd : {};
  return {
    collectorPort: Number.isInteger(mc.sflow.port) ? mc.sflow.port : 6343,
    samplingRate: h.samplingRate,
    pollingSecs: h.pollingSecs,
    device: h.device,
  };
}

// Ties the WebSocket client and the REST client together:
//   - reports its capabilities and fetches its server-assigned monitor config
//     (which traffic source to use: proc or snmp);
//   - on a server "run test" command it measures + submits once;
//   - independently, it reports traffic on a fixed interval (continuous
//     reporting) so the server gets data without anyone triggering it.
// A token rejected over REST/WS (401) is fatal: it stops and does NOT re-enroll.
//
// Events: 'open', 'connected', 'close', 'results-submitted', 'command-ignored',
// 'command-error', 'config', 'fatal'. It never calls process.exit.
function createAgentRuntime({
  config,
  token,
  agentId,
  logger,
  fetchImpl = fetch,
  WebSocketImpl,
  samplerFactory = createSampler,
  capabilities = detectCapabilities(),
  probeRunner = runProbe,
  resolveTargets = resolveProbeTargets,
  collectNic = collectNicInfo,
  collectLocalIps = collectLocalIpsDefault,
  collectConns = collectConnections,
  collectArp = collectArpTable,
  // This host's own LLDP neighbours, via lldpd when it is installed. Resolves
  // { neighbours, chassisId } or { unavailable }. Injectable for tests.
  collectLldp = collectLldpDefault,
  // Resolves an SNMP target's hostname to the addresses its traps will come
  // from. dns.lookup-shaped ({ all: true } → [{ address, family }]).
  lookupHost = (host) => dns.promises.lookup(host, { all: true }),
  discoveryScanner = createScanner(),
  collectCidrs = collectLocalCidrs,
  selfUpdater = null,
  selfDeleter = null,
  toolInstaller = null,
  actionLog = null,
  hsflowdManager = null,
  // Receives syslog from the network devices pointing at this host. Injectable
  // so tests drive it through ingestLine() without binding a port; null means
  // "build the real one if config.syslogEnabled".
  syslogReceiver = null,
  // Builds the real syslog receiver when syslog is enabled. Injectable so a test
  // can see the sender filter the runtime hands it.
  syslogReceiverFactory = createSyslogReceiver,
  // Polls the switches the server assigned to THIS agent, alongside its own
  // traffic sampling. Injectable so tests drive runCycle() without net-snmp.
  snmpPoller = null,
  // Receives SNMP traps from those same switches. Injectable so tests drive
  // ingestDatagram() without binding a port or needing net-snmp.
  trapReceiver = null,
  // Builds the real trap receiver when traps are enabled. Injectable so a test
  // can see the sender allowlist and ifName resolver the runtime hands it.
  trapReceiverFactory = createTrapReceiver,
  // One-target, once-a-second measurement on command. Injectable so tests run
  // a two-minute burst against a fake clock.
  burstRunner = null,
  // Injected by tests so a capture is exercised without spawning tcpdump.
  captureRunner = null,
  captureSupport = detectCaptureSupport,
  // Injected into every transaction executor (fake http/connect/resolver), so a
  // transaction run is exercised without reaching the network.
  transactionExecutorDeps = {},
  // Where a server-sent rekey stores this host's trust anchor (beside the token —
  // the one directory the agent is guaranteed to be able to write). Injectable.
  pinnedKeyPath = keyStore.pinnedKeyPath(config && config.tokenPath),
  keys = keyStore,
  // Blue/green layout + the guard that rolls a release back when it never
  // proves itself. Injectable so tests can point them at a scratch directory.
  releasesDir = process.env.BLUEEYE_RELEASES_DIR || '',
  guard = releaseGuard,
  confirmReleaseAfterMs = releaseGuard.DEFAULT_CONFIRM_MS,
  // Bounded hold for measurements the server could not take (resultSpool.js).
  // Injectable so a test can watch what was kept and what was dropped.
  resultSpool = null,
  // The release trust anchor; injectable for tests. A key pinned here by an
  // accepted rekey wins over the one the installer baked into the environment.
  releasePublicKey = resolveReleasePublicKey(process.env, { pinnedPath: pinnedKeyPath, readPinned: (f) => keys.readPinnedKey(f) }),
  // Refuse a privileged command (update/delete/install-tool) that carries no
  // server signature. DEFAULTS ON wherever a release key is pinned — that agent
  // can check a signature and its server can make one, so accepting an unsigned
  // command would mean the WebSocket session alone is enough to reconfigure the
  // host. An agent with no key pinned stays lenient (nothing could verify
  // anything), and BLUEEYE_REQUIRE_SIGNED_COMMANDS overrides either way.
  // A RATCHET, not a fixed policy: leniency is dropped the first time this
  // server proves it can sign a command, and never comes back. Deriving it from
  // "a key is pinned" instead bricked every privileged command on a fleet whose
  // server had lost its signing key — see requireSignedCommands.
  strictCommands = requireSignedCommands(process.env, {
    signedBefore: keys.readTrustState(pinnedKeyPath).commandsSigned,
  }),
  // Break-glass: allow an UNSIGNED rekey to replace a trust anchor this host
  // already holds. Off by default — see the long note in src/commandAuth.js for
  // why rekey does not follow strictCommands' lenient default. Setting it needs
  // access to the host, which is the authority re-anchoring trust deserves.
  allowUnsignedRekey = allowUnsignedRekeyEnv(),
}) {
  const emitter = new EventEmitter();
  // The trust anchor in force RIGHT NOW. Mutable because a `rekey` command
  // replaces it while the agent runs: the update that follows it must verify
  // against the new key without waiting for a restart.
  let pinnedKey = releasePublicKey;
  // The SECOND anchor, and the normal state is not to have one.
  //
  // When the vendor has authorised a separate command key for this licence, a
  // rekey with `purpose: 'command'` pins it here and privileged commands are
  // checked against it instead of the release key. Until then this is empty and
  // commands are checked against the release key — which is what every agent in
  // the field does, and is why the split can be rolled out without a flag day.
  //
  // Read from the file only. There is no environment override on purpose: the
  // installer bakes in a release key for trust-on-first-use, but a command key
  // only ever arrives with a vendor authorisation, and an env var would be a way
  // to introduce one without it.
  let pinnedCommandKey = keys.readPinnedKey(keys.commandKeyPath(pinnedKeyPath)) || '';
  // Which key a privileged command's signature must verify against. One place,
  // because "which anchor applies" must not be answerable differently in two.
  const commandKey = () => pinnedCommandKey || pinnedKey;
  // One per runtime: the commandIds already carried out, so a captured signed
  // command cannot be replayed at this agent inside its validity window. Backed
  // by a file beside the pinned key, so a restart does not forget them — the
  // window right after a restart is where an in-memory set let a replay through.
  const replayGuard = createReplayGuard({
    file: keys.replayStatePath(pinnedKeyPath),
    onWarn: (m) => logger.warn(m),
  });
  const updater = selfUpdater || createSelfUpdater({ logger, runtime: capabilities.managed });
  // The deleter must wipe the token the runtime actually uses: tokenPath can be
  // set via the config FILE (not just env), and selfDelete's own default only
  // sees the env — so a file-configured path would be left un-wiped.
  const deleter = selfDeleter || createSelfDeleter({ logger, tokenPath: config.tokenPath });
  const installer = toolInstaller || createToolInstaller({ logger });
  // Local, server-independent action trail. Path comes from the env at
  // provisioning (BLUEEYE_ACTION_LOG); a no-op when unset. Never logs secrets.
  const actions = actionLog || createActionLog({ path: process.env.BLUEEYE_ACTION_LOG || '' });
  // When a cert fingerprint is configured and the server is https, pin it on the
  // REST calls too (the WS client pins separately). Falls back to the injected
  // fetch (or global fetch) otherwise — so tests that inject a fetch are unaffected.
  // Several pins may be configured so a certificate can be renewed without
  // locking the fleet out; `serverCertFingerprint` (the first) stays for config
  // files and callers that only ever knew one.
  const fp = (config.serverCertFingerprints && config.serverCertFingerprints.length)
    ? config.serverCertFingerprints
    : config.serverCertFingerprint;
  const anyHttps = [config.serverUrl, ...(config.serverUrls || [])].some((u) => /^https:/i.test(String(u || '')));
  const hasPin = Array.isArray(fp) ? fp.length > 0 : !!fp;
  const effectiveFetch = (hasPin && anyHttps) ? makePinnedFetch(fp) : fetchImpl;
  // The live channel decides which of the configured URLs is in use; REST
  // follows it, so a failover moves the whole agent rather than half of it.
  const client = createAgentClient({
    serverUrl: config.serverUrl,
    serverUrls: config.serverUrls,
    token,
    logger,
    heartbeatMs: config.heartbeatMs,
    backoff: config.backoff,
    WebSocketImpl,
    certFingerprint: fp,
    staleConnectionMs: config.staleConnectionMs,
    socketKeepAliveMs: config.socketKeepAliveMs,
    authRetryMs: config.authRetryMs,
  });
  const api = createApiClient({
    serverUrl: () => (typeof client.activeServerUrl === 'function' ? client.activeServerUrl() : config.serverUrl),
    token,
    fetchImpl: effectiveFetch,
  });
  // Measurements the server could not take. A reading is taken at a moment that
  // does not come back, so an outage should cost a delay in DELIVERY, not a hole
  // in the history. Bounded, oldest dropped (resultSpool.js).
  const spool = resultSpool || createResultSpool({ max: config.resultSpoolMax, logger });

  // Transaction-test executor: runs server-pushed http/tcp/dns/icmp tests on their
  // own schedule (interval_sec ± 10% jitter), buffers results while offline (max
  // 1000, oldest dropped) and flushes on reconnect. Secrets are persisted
  // encrypted with a key derived from the token, and decrypted only in memory.
  const transactionConfigPath = config.transactionConfigPath
    || path.join(path.dirname(config.tokenPath || '.'), 'transactions.json');
  // Header capture for transaction runs. Built unconditionally: it binds
  // nothing, spawns nothing and allocates nothing until a run that asks for one
  // actually starts, and a host where it cannot work refuses per run with a
  // reason (which `capabilities.unavailable.capture` has already reported).
  const capture = captureRunner || createCaptureRunner({ logger });
  const txManager = createTransactionManager({
    send: (obj) => client.send(obj),
    configStore: createConfigStore({ filePath: transactionConfigPath, secretStore: createSecretStore(token), logger }),
    buffer: createResultBuffer({ max: 1000 }),
    executorDeps: transactionExecutorDeps,
    logger,
    capture,
  });
  client.on('transaction-config', (tests) => {
    try { txManager.applyConfig(tests); } catch (err) { logger.warn(`Failed to apply transaction config: ${err.message}`); }
  });

  // Syslog: built only when enabled, so a host that never turned it on binds
  // nothing and allocates nothing. An injected receiver always wins (tests).
  const syslog = syslogReceiver || (config.syslogEnabled
    ? syslogReceiverFactory({
      port: config.syslogPort,
      bindAddress: config.syslogBindAddress,
      udp: config.syslogUdp,
      tcp: config.syslogTcp,
      maxEvents: config.syslogMaxEvents,
      ratePerSec: config.syslogRatePerSec,
      // Resolved lazily per line, so a sender added by a re-applied SNMP
      // target list is accepted without rebuilding the receiver.
      isAllowedSender: (ip) => isAllowedSyslogSender(ip),
      logger,
    })
    : null);
  // ONE flush timer for syslog AND traps — they drain into the same batch. It
  // starts when EITHER receiver binds, so a trap-only agent flushes too.
  let deviceEventTimer = null;
  let syslogBound = null; // what start() actually managed to bind, or null
  let lastDeviceEventAt = null; // ms epoch of the last successful flush

  // SNMP topology. Built unconditionally (it does nothing without targets) so
  // the server can start assigning switches to an already-running agent without
  // waiting for a restart.
  const snmp = snmpPoller || createSnmpPoller({
    submit: (payload) => api.postSnmpTopology(payload),
    submitCounters: (payload) => api.postSnmpCounters(payload),
    logger,
  });
  let snmpTargetCount = 0;
  let lastSnmpAt = null; // ms epoch of the last successful submit
  let lastSnmpCounterAt = null;

  // Interface names learned by the SNMP topology poll, keyed by device, so a
  // trap saying "ifIndex 1" can be shown as "GigabitEthernet0/1". Populated
  // from the poll results the agent already submits — scheduled cycles and a
  // forced poll-snmp alike; a device not in here resolves to null and the trap
  // shows the index, which is honest.
  const ifNamesByDeviceId = new Map(); // deviceId -> Map(ifIndex -> ifName)
  const hostByDeviceId = new Map();
  // The ADDRESSES each polled device is reached at. A trap arrives from an IP,
  // and a switch configured by hostname ("sw-core-1.lan") never matched the
  // string compare this used to be. A literal IP is its own entry; a hostname
  // is resolved when the targets are applied (and again on every re-apply).
  const addressesByDeviceId = new Map(); // deviceId -> Set(address)
  // The v1/v2c community each device is polled with, so a trap claiming to be
  // from it must carry the same one. A v3 target (or none assigned) has no
  // entry, and its traps are checked on address alone.
  const communityByDeviceId = new Map(); // deviceId -> community
  let targetResolveGeneration = 0;

  function rememberInterfaces(result) {
    if (!result || !hostByDeviceId.has(result.deviceId) || !Array.isArray(result.interfaces)) return;
    const names = new Map();
    for (const i of result.interfaces) {
      if (Number.isInteger(i.ifIndex) && i.ifName) names.set(i.ifIndex, i.ifName);
    }
    if (names.size) ifNamesByDeviceId.set(result.deviceId, names);
  }

  function deviceIdForAddress(sourceIp) {
    for (const [deviceId, addrs] of addressesByDeviceId) {
      if (addrs.has(sourceIp)) return deviceId;
    }
    return undefined;
  }

  function resolveTrapIfName(sourceIp, ifIndex) {
    const deviceId = deviceIdForAddress(sourceIp);
    const names = deviceId === undefined ? null : ifNamesByDeviceId.get(deviceId);
    return names ? (names.get(ifIndex) || null) : null;
  }

  // An SNMPv2c trap is unauthenticated: anyone who can route UDP here can claim
  // to be any switch. The source address is all we have, so a trap is accepted
  // only from an address this agent actually polls. Weak, and the strongest
  // check v2c permits.
  function isPolledSender(sourceIp) {
    return deviceIdForAddress(sourceIp) !== undefined;
  }

  function expectedTrapCommunity(sourceIp) {
    const deviceId = deviceIdForAddress(sourceIp);
    return deviceId === undefined ? null : (communityByDeviceId.get(deviceId) || null);
  }

  // Syslog senders. Empty config = accept every sender, as before. Otherwise a
  // sender is accepted when EITHER configured source vouches for it: it is in
  // syslogAllowedSenders, or syslogOnlyPolled is on and it is a switch this
  // agent polls (the same resolved addresses the trap allowlist uses). A union,
  // because the firewall that logs is rarely a device anybody polls over SNMP.
  const syslogSenderList = parseSenderAllowlist(config.syslogAllowedSenders);
  if (config.syslogEnabled && syslogSenderList.invalid.length) {
    logger.warn(`syslogAllowedSenders: ignoring invalid entr${syslogSenderList.invalid.length === 1 ? 'y' : 'ies'} ${syslogSenderList.invalid.join(', ')}.`);
  }
  const syslogOnlyPolled = config.syslogOnlyPolled === true;
  function isAllowedSyslogSender(sourceIp) {
    if (!syslogSenderList.configured && !syslogOnlyPolled) return true;
    if (syslogSenderList.configured && syslogSenderList.match(sourceIp)) return true;
    return syslogOnlyPolled && isPolledSender(sourceIp);
  }

  // Traps: built only when enabled, like syslog. Shares the device-event flush,
  // because a trap and a syslog line are the same thing over a different socket.
  const traps = trapReceiver || (config.trapsEnabled
    ? trapReceiverFactory({
      port: config.trapPort,
      bindAddress: config.trapBindAddress,
      maxEvents: config.trapMaxEvents,
      ratePerSec: config.trapRatePerSec,
      isKnownSender: isPolledSender,
      expectedCommunity: expectedTrapCommunity,
      checkCommunity: config.trapsCheckCommunity === true,
      resolveIfName: resolveTrapIfName,
      logger,
    })
    : null);
  let trapsBound = null;

  // Burst mode. Built unconditionally: it binds nothing and allocates nothing
  // until a command arrives, and it is the one tool that must be available the
  // moment somebody is standing in front of a fault.
  const burst = burstRunner || createBurstRunner({ probeRunner, logger });

  let reportTimer = null;
  let capabilitiesTimer = null;
  let configRefreshTimer = null;
  // What the last successful config load APPLIED, as a key-order-independent
  // string, so a periodic refresh that finds the same config changes nothing.
  let appliedMonitorKey = null;
  let appliedTargetsKey = null;
  // Config loads run one at a time: a reconnect, the periodic refresh and a
  // poll-snmp can all ask at once, and two interleaved loads would each tear
  // down the sampler the other just built.
  let configChain = Promise.resolve();
  let reportingStarted = false; // true once the bootstrap called startReporting()
  let probeTimer = null;
  let fatal = false;
  let monitorConfig = { source: 'proc' };
  let currentSampler = samplerFactory(monitorConfig, { logger });
  let effectiveIntervalMs = config.reportIntervalMs;
  // Self-managed host sFlow exporter (hsflowd). Only acts when the monitor
  // source is sflow with a local exporter requested; on a containerised agent it
  // defers to the hsflowd sidecar.
  const hsflowd = hsflowdManager || createHsflowdManager({ runtime: capabilities.managed, logger });
  let hsflowdManaged = false;
  let lastHsflowdState = null;
  let lastReportAt = null; // ms epoch of the last successful results submission

  function handleFatal(reason = 'rest-token-rejected') {
    if (fatal) return;
    fatal = true;
    stopReporting();
    stopCapabilitiesReporting();
    stopConfigRefresh();
    logger.error('Token rejected (HTTP 401); stopping. Will NOT re-enroll automatically.');
    client.stop();
    emitter.emit('fatal', reason);
  }

  // A 401 on a REST call. Terminal only when no auth retry is configured.
  // Otherwise the agent PAUSES — it stops measuring and reporting into a server
  // that will not have it — while the live channel keeps re-dialling on its long
  // timer. A token the server starts accepting again (a restore from backup, a
  // re-provisioned server, a rotation someone finished) then brings the agent
  // back by itself, which is the whole point: the fleet must not need a shell on
  // every host to recover from a server-side mistake.
  let authPaused = false;
  function handleTokenRejected(reason = 'rest-token-rejected') {
    if (config.authRetryMs > 0) {
      if (fatal || authPaused) return;
      authPaused = true;
      stopReporting();
      stopCapabilitiesReporting();
      stopConfigRefresh();
      logger.error(
        `Token rejected (HTTP 401); pausing. Not re-enrolling; the connection keeps retrying every ${Math.round(config.authRetryMs / 1000)}s.`
      );
      emitter.emit('auth-rejected', { reason, retryInMs: config.authRetryMs });
      return;
    }
    handleFatal(reason);
  }

  // The token works again. Puts back everything handleTokenRejected stopped.
  function resumeAfterAuth() {
    if (!authPaused || fatal) return;
    authPaused = false;
    logger.info('Token accepted again; resuming reporting.');
    startCapabilitiesReporting();
    startConfigRefresh();
    if (reportingStarted) startReporting();
    emitter.emit('auth-recovered');
  }

  // Ships a non-fatal operational error to the server over the live channel so it
  // surfaces in the server's audit trail (Reporting → Audit) — not just the local
  // log. Best-effort and metadata-only: a closed socket just drops it (the server
  // already infers offline), `category` lets the server collapse repeats onto one
  // row, and `message` is the Error text, never measured payload. A 401 is handled
  // by handleFatal, not reported here. Never throws.
  function reportError(category, err) {
    try {
      client.send({
        type: 'agent.error',
        category,
        code: (err && err.code) || null,
        message: err && err.message ? String(err.message).slice(0, 300) : 'error',
      });
    } catch { /* error reporting must never throw */ }
  }

  // Measures traffic (with the currently selected sampler) and submits it. A 401
  // is fatal; other errors are surfaced but non-terminal so the loop continues.
  async function runAndSubmit(command, source) {
    try {
      const sampler = currentSampler;
      const measured = await runTest(command, { sampler });
      // The server refuses a result over 64 KB — the whole report, not the
      // part that was too big — so an oversize one is trimmed first, in a
      // fixed order, and says so (resultBudget.js). sFlow counter readings
      // that had to go are handed back to the collector for next interval.
      const fitted = fitResult(measured);
      if (fitted.marker) {
        logger.warn(`Traffic result was ${fitted.originalBytes} bytes, over the ${fitted.marker.budgetBytes}-byte budget; trimmed ${describeTrim(fitted.marker)}.`);
        const counters = fitted.removed['traffic.sflowCounters'];
        if (counters && counters.length && typeof sampler.requeueCounters === 'function') {
          try { sampler.requeueCounters(counters); } catch { /* best-effort */ }
        }
      }
      if (fitted.oversize) {
        const err = new Error(`Traffic result is ${fitted.bytes} bytes even after trimming; not sent.`);
        err.code = 'RESULT_TOO_LARGE';
        throw err;
      }
      const result = fitted.value;
      const response = await spool.deliver('traffic', [result], (items) => api.postResults(items));
      lastReportAt = Date.now();
      logger.info(`Traffic measured (${source}, ${monitorConfig.source}); results submitted.`);
      emitter.emit('results-submitted', { result, response, source });
      return true;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') {
        handleTokenRejected();
        return false;
      }
      const waiting = typeof err.spooled === 'number' ? err.spooled : spool.pending('traffic');
      logger.error(`Failed to measure/submit traffic (${source}): ${err.message}${waiting ? ` (${waiting} batch(es) spooled for the next attempt)` : ''}`);
      reportError('traffic-report', err);
      emitter.emit('command-error', err);
      return false;
    }
  }

  // Runs one active probe (ping/tcp/dns/traceroute) and submits the result. A
  // 401 is fatal; other errors are surfaced but non-terminal.
  //
  // A traceroute streams each hop over the WebSocket as the binary prints it
  // (`trace_hop`), so the dashboard draws the path while the trace runs. Only
  // for on-demand runs — scheduled traces have nobody watching. A dropped
  // frame costs one hop on the live view; the submitted result is the record.
  async function runProbeAndSubmit(probeSpec) {
    try {
      const result = await probeRunner(probeSpec, liveTraceDeps(probeSpec));
      const response = await spool.deliver('probe', [result], (items) => api.postProbeResults(items));
      const outcome = describeProbeOutcome(result);
      logger.info(`Probe ${result.type} → ${result.target}: ${outcome}.`);
      emitter.emit('probe-submitted', { result, response });
      return true;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return false; }
      logger.error(`Failed to run/submit probe: ${err.message}`);
      reportError('probe', err);
      emitter.emit('command-error', err);
      return false;
    }
  }

  function liveTraceDeps(spec) {
    const probeType = String((spec && spec.type) || '').toLowerCase();
    if (probeType !== 'traceroute' && probeType !== 'tcptraceroute') return undefined;
    const host = String((spec && (spec.host || spec.target)) || '').trim();
    // The same target string the finished result carries, so the dashboard
    // can match a hop to the trace it is waiting on.
    const target = probeType === 'tcptraceroute' ? `${host}:${spec.port !== undefined ? spec.port : 443}` : host;
    const onHop = (hop) => {
      try { client.send({ type: 'trace_hop', probeType, target, hop }); } catch { /* not connected */ }
    };
    return { [probeType]: { onHop } };
  }

  // Runs an active-discovery sweep from THIS agent's vantage and reports the
  // candidates. Scope resolution: the server-provided CIDRs, or — when empty —
  // this host's own subnet(s) ("scan the segment I'm on"). The scanner enforces
  // the address cap + scope guard and refuses an empty/over-cap scope (reported
  // back as a refusal, not a crash). Native probes only; never a write action.
  async function runDiscoveryAndSubmit(spec) {
    const d = spec && typeof spec === 'object' ? spec : {};
    const requestId = d.requestId != null ? d.requestId : null;
    let cidrs = Array.isArray(d.cidrs) ? d.cidrs.map((c) => String(c).trim()).filter(Boolean) : [];
    let derivedFromSelf = false;
    if (!cidrs.length) { cidrs = collectCidrs(); derivedFromSelf = true; }
    const startedAt = new Date().toISOString();
    try {
      const result = await discoveryScanner.scan({
        cidrs,
        addressCap: d.addressCap != null ? Number(d.addressCap) : 65536,
        ratePerSec: d.rateLimit != null ? Number(d.rateLimit) : 50,
        portList: Array.isArray(d.ports) && d.ports.length ? d.ports.map(Number).filter((n) => n > 0) : undefined,
      });
      const payload = {
        requestId,
        scope: cidrs,
        derivedFromSelf,
        addresses: result.addresses,
        probed: result.probed.length,
        candidates: result.candidates,
        startedAt,
        endedAt: new Date().toISOString(),
      };
      await api.postDiscoveryResults(payload);
      logger.info(`Discovery swept ${result.addresses} addr(s) in ${cidrs.join(', ') || '(none)'} → ${result.candidates.length} candidate(s).`);
      emitter.emit('discovery-submitted', payload);
      return true;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return false; }
      // A scope refusal is an expected outcome, not an error — report it so the
      // server can audit "refused (reason)" instead of the sweep vanishing.
      if (err instanceof DiscoveryScopeError) {
        try {
          await api.postDiscoveryResults({ requestId, scope: cidrs, derivedFromSelf, refused: true, reason: err.code, candidates: [], startedAt, endedAt: new Date().toISOString() });
        } catch { /* best-effort */ }
        logger.warn(`Discovery refused: ${err.code}.`);
        emitter.emit('discovery-refused', { reason: err.code });
        return false;
      }
      logger.error(`Failed to run/submit discovery: ${err.message}`);
      reportError('discovery', err);
      emitter.emit('command-error', err);
      return false;
    }
  }

  // Header-capture support, probed at most once while it keeps saying yes. A
  // negative answer is not cached: the two things that cause it (no tcpdump, no
  // CAP_NET_RAW) are both fixable from outside, and an agent that cached "no" at
  // boot would keep saying it for as long as it ran.
  let captureSupportMemo = null;
  async function captureSupportCached() {
    if (captureSupportMemo && captureSupportMemo.available) return captureSupportMemo;
    captureSupportMemo = await captureSupport({});
    return captureSupportMemo;
  }

  // Reports capabilities to the server. Resilient: only a 401 is fatal. NIC
  // inventory (driver/firmware per interface) is collected best-effort and
  // folded in, so the server can spot fleet-wide firmware drift; a failure to
  // read it just omits the field.
  async function reportCapabilities() {
    let payload = capabilities;
    try {
      const nic = await collectNic();
      // ...payload, not ...capabilities: every block below extends what the one
      // before it built, and rebuilding from the base here silently dropped
      // whatever had already been added.
      if (Array.isArray(nic) && nic.length) payload = { ...payload, nic };
    } catch { /* NIC inventory is best-effort */ }
    try {
      const ips = collectLocalIps();
      if (Array.isArray(ips) && ips.length) payload = { ...payload, ips };
    } catch { /* own-IP list is best-effort */ }
    try {
      // Established-TCP connection table → directed service-dependency edges, so a
      // proc/snmp-only host (no NetFlow/sFlow) still feeds the server's graph.
      const connections = await collectConns();
      if (Array.isArray(connections) && connections.length) payload = { ...payload, connections };
    } catch { /* connection table is best-effort */ }
    try {
      // ARP/neighbour table → the server's IP<->MAC identity source, so a
      // technician can search for the address they were told instead of a
      // hostname they have to look up first. Metadata only.
      const arp = await collectArp();
      if (Array.isArray(arp) && arp.length) payload = { ...payload, arp };
    } catch { /* neighbour table is best-effort */ }
    try {
      // This host's own LLDP neighbours (lldpd) → the server's lldp_neighbors
      // + topology-change detection: which switch port this machine is on.
      // Sent only when lldpd ANSWERED — an empty list is a snapshot ("nobody
      // there any more") the server diffs against, so a host that merely
      // cannot ask must omit the field, and says why under `unavailable`.
      const lldp = await collectLldp();
      if (lldp && Array.isArray(lldp.neighbours)) {
        payload = { ...payload, lldp: lldp.neighbours };
        if (lldp.chassisId) payload = { ...payload, lldpChassisId: lldp.chassisId };
      } else if (lldp && lldp.unavailable) {
        payload = { ...payload, unavailable: { ...(payload.unavailable || {}), lldp: String(lldp.unavailable) } };
      }
    } catch { /* LLDP is best-effort */ }
    try {
      // CAN THIS HOST CAPTURE HEADERS AT ALL? Reported so the dashboard can
      // offer the option only where it works, and name the reason where it does
      // not — "tcpdump is not installed" is a thing an operator can fix, while a
      // capture that silently never happens is not. Probed once and remembered;
      // an unavailable host is re-probed on each report, so installing tcpdump
      // (or granting the capability) is picked up without a restart.
      const support = await captureSupportCached();
      if (support.available) payload = { ...payload, capture: true };
      else payload = { ...payload, unavailable: { ...(payload.unavailable || {}), capture: String(support.reason || 'unavailable') } };
    } catch { /* capture support is best-effort */ }
    // WHICH KEY THIS AGENT TRUSTS. A fingerprint of the PUBLIC release key it
    // pins — never the key, never a secret, and the one fact that turns
    // "refused: command signature verification failed" from a mystery into a
    // sentence: this agent trusts ab12…, this server signs with cd34…, so
    // re-pin it. Without it the dashboard can see THAT an agent refuses every
    // signed command and not WHY, and nobody can look: these hosts have no
    // shell. Added last so a later rekey is reflected on the next report.
    try {
      payload = { ...payload, releaseKeyFingerprint: pinnedKey ? keys.fingerprintOf(pinnedKey) : null };
    } catch { /* a diagnostic is never a reason to fail the report it rides on */ }
    try {
      await api.postCapabilities(payload);
      const nicNote = payload.nic ? ` + ${payload.nic.length} NIC(s)` : '';
      const connNote = payload.connections ? ` + ${payload.connections.length} conn edge(s)` : '';
      const arpNote = payload.arp ? ` + ${payload.arp.length} ARP entr(ies)` : '';
      const lldpNote = payload.lldp ? ` + ${payload.lldp.length} LLDP neighbour(s)` : '';
      logger.info(`Reported capabilities: ${capabilities.sources.join(', ') || '(none)'}${nicNote}${connNote}${arpNote}${lldpNote}`);
      emitter.emit('capabilities-reported', payload);
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return; }
      logger.warn(`Could not report capabilities (${err.message}).`);
      reportError('capabilities', err);
    }
  }

  // Fetches the server-assigned config (monitorConfig + snmpTargets) and applies
  // it. Resilient: only a 401 is fatal; otherwise keep the current source.
  //
  // `force` (bootstrap, WS reconnect): rebuild the sampler and reconcile hsflowd
  // even when nothing changed — the reconnect is also when the exporter state is
  // re-sent to the server. Without it (the periodic refresh, poll-snmp) an
  // UNCHANGED config is a no-op: no sampler restart (which would drop a
  // collector's in-flight flows), no hsflowd reconcile, no target re-apply.
  //
  // Resolves { ok, changed, devices } — never rejects.
  function loadServerConfig(opts) {
    const run = configChain.then(() => applyServerConfig(opts || {}));
    configChain = run.catch(() => {});
    return run;
  }

  async function applyServerConfig({ force = true } = {}) {
    try {
      // The WHOLE body, not just monitorConfig: the same call also carries
      // `snmpTargets`, the switches this agent polls.
      const body = await api.getFullConfig();
      if (fatal) return { ok: false, changed: false, devices: snmpTargetCount };
      const mc = (body && body.monitorConfig) || { source: 'proc' };
      // The version the server offers, and whether it will let this agent go and
      // get it. Evaluated on every config read, which is what reaches an agent
      // that is only online for a few minutes at a time — nobody has to time a
      // click to its connection any more.
      considerSelfUpdate(body && body.updates);
      const targets = body ? body.snmpTargets : undefined;
      const targetsKey = stableKey(targets === undefined ? null : targets);
      const targetsChanged = targetsKey !== appliedTargetsKey;
      if (force || targetsChanged) {
        applySnmpTargets(targets);
        appliedTargetsKey = targetsKey;
      }
      const monitorKey = stableKey(mc);
      if (!force && monitorKey === appliedMonitorKey) {
        return { ok: true, changed: targetsChanged, devices: snmpTargetCount };
      }
      monitorConfig = mc;
      // Dispose the previous sampler's background lifecycle (e.g. a netflow
      // UDP socket) before swapping in the new source.
      if (currentSampler && typeof currentSampler.stop === 'function') currentSampler.stop();
      currentSampler = samplerFactory(monitorConfig, { logger });
      appliedMonitorKey = monitorKey;
      const prevIntervalMs = effectiveIntervalMs;
      effectiveIntervalMs =
        Number.isInteger(mc.intervalMs) && mc.intervalMs > 0 ? mc.intervalMs : config.reportIntervalMs;
      logger.info(`Monitor source: ${monitorConfig.source} (report every ${effectiveIntervalMs}ms).`);
      emitter.emit('config', monitorConfig);
      // A reconnect can carry a changed reporting interval; the bootstrap timer
      // keeps its old cadence unless restarted here. Only after the bootstrap
      // has started reporting — during bootstrap loadServerConfig() runs first
      // and startReporting() follows right after.
      if (reportingStarted && effectiveIntervalMs !== prevIntervalMs) {
        stopReporting();
        startReporting();
      }
      await reconcileHsflowd();
      return { ok: true, changed: true, devices: snmpTargetCount };
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return { ok: false, changed: false, devices: 0 }; }
      logger.warn(`Could not fetch monitor config (${err.message}); using ${monitorConfig.source}.`);
      reportError('config', err);
      return { ok: false, changed: false, devices: snmpTargetCount, error: err.message };
    }
  }

  // Asking for our own update.
  //
  // Updates used to be pure push: an admin clicked, and the click had to land
  // while the agent was connected. An agent that is online for ten minutes a day
  // was therefore effectively un-updatable, and nothing on the agent even knew it
  // was behind. Now the server states what it offers in the config this agent
  // already reads, and the agent asks.
  //
  // Everything here is a reason NOT to ask; the server re-checks all of it before
  // it sends anything, because a permission that travelled to a host and back is
  // not a decision the server made:
  //
  //   * the local opt-out (`autoUpdate` in the agent config) — one host can
  //     refuse without the server having to know;
  //   * the server's policy flag, off by default;
  //   * a runtime that can actually be restarted onto new code;
  //   * the offered version being NEWER than ours, never merely different — a
  //     downgrade is not an update;
  //   * the maintenance window, in this host's own local time. A monitoring agent
  //     restarting mid-incident is its own kind of outage;
  //   * once per offered version. A reconnect loop must not become an update loop.
  let requestedUpdateFor = null;
  function considerSelfUpdate(updates) {
    if (!updates || typeof updates !== 'object') return;
    const offered = updates.agentVersion ? String(updates.agentVersion) : '';
    if (!offered) return;
    if (!config.autoUpdateEnabled) return;
    if (!updates.auto) return;
    if (!isSelfUpdatable(capabilities.managed)) return;
    const current = capabilities.agentVersion || '';
    if (!current || !isNewerVersion(offered, current)) return;
    if (!isWithinWindow(updates.window || '')) {
      logger.info(`Update to v${offered} is available but outside the maintenance window (${updates.window}); waiting.`);
      return;
    }
    if (requestedUpdateFor === offered) return;
    requestedUpdateFor = offered;
    if (client.send({ type: 'update-request', currentVersion: current, offeredVersion: offered })) {
      logger.info(`Agent is on v${current} and the server offers v${offered}; requested the update.`);
      actions.log('update.requested', { from: current, to: offered });
      emitter.emit('update-requested', { from: current, to: offered });
    } else {
      // Not connected: nothing was asked, so do not remember having asked.
      requestedUpdateFor = null;
    }
  }

  // loadServerConfig with a deadline, for a command that must answer: a slow
  // or hung server costs poll-snmp at most `ms`, after which it polls with the
  // targets it already had. The load itself carries on and applies when it
  // lands. Never rejects.
  function loadServerConfigWithin(ms, opts) {
    let timer;
    const deadline = new Promise((resolve) => {
      timer = setTimeout(() => resolve({ ok: false, changed: false, devices: snmpTargetCount, error: 'timeout' }), ms);
      if (timer.unref) timer.unref();
    });
    return Promise.race([loadServerConfig(opts), deadline]).finally(() => clearTimeout(timer));
  }

  // Re-reads the server config on a cadence, so a switch assigned to a running
  // agent — or a changed traffic source — applies without waiting for the
  // connection to drop. Skipped while disconnected (the reconnect loads it
  // anyway) and after a fatal; unref'd; 0 disables it.
  function startConfigRefresh() {
    stopConfigRefresh();
    const intervalMs = config.configRefreshIntervalMs;
    if (fatal || !Number.isFinite(intervalMs) || intervalMs <= 0) return;
    let running = false;
    configRefreshTimer = setInterval(async () => {
      if (fatal || running || !client.isConnected()) return;
      running = true;
      try {
        const r = await loadServerConfig({ force: false });
        emitter.emit('config-refreshed', r);
      } finally { running = false; }
    }, intervalMs);
    if (configRefreshTimer.unref) configRefreshTimer.unref();
  }

  function stopConfigRefresh() {
    if (configRefreshTimer) {
      clearInterval(configRefreshTimer);
      configRefreshTimer = null;
    }
  }

  // Was the host's hsflowd provisioned by this agent — now, or by a PREVIOUS
  // process? The in-memory flag dies with a restart; the manager re-derives it
  // from the conf marker. Injected test fakes without isManaged() mean "no".
  // Never throws.
  async function managedByThisAgent() {
    try {
      return typeof hsflowd.isManaged === 'function' ? !!(await hsflowd.isManaged()) : false;
    } catch { return false; }
  }

  // Converges the local hsflowd exporter to the server's desired state. Runs on
  // every config load — i.e. at startup and on each WS reconnect — so the host
  // re-reconciles whenever it reconnects. Never throws (the manager swallows OS
  // errors and reports a state instead).
  async function reconcileHsflowd() {
    const opts = sflowExporterOptions(monitorConfig);
    let r = null;
    if (opts) {
      r = await hsflowd.enable(opts);
      hsflowdManaged = true;
    } else if (hsflowdManaged || (await managedByThisAgent())) {
      // The source moved away from sflow (or the exporter was switched off) and
      // we were managing it — possibly in a previous process: the conf marker
      // outlives a restart, so the exporter doesn't end up orphaned. Stop it,
      // but leave it installed for a fast re-enable.
      r = await hsflowd.disable();
      hsflowdManaged = false;
    }
    if (!r) return;
    lastHsflowdState = r;
    logger.info(`hsflowd: ${r.state}${r.detail ? ` (${r.detail})` : ''}.`);
    emitter.emit('hsflowd', r);
    // Report the observed state to the server (best-effort) so the dashboard can
    // show whether the exporter actually came up after an enable/disable. If the
    // socket isn't open it's re-sent on the next reconnect (reconcile runs then).
    try { client.send({ type: 'sflow.status', state: r.state, detail: r.detail || null }); } catch { /* not connected */ }
  }

  function startReporting() {
    if (fatal) return;
    reportingStarted = true;
    if (!effectiveIntervalMs || effectiveIntervalMs <= 0) {
      logger.info('Continuous reporting disabled (interval <= 0).');
      return;
    }
    stopReporting();
    const command = { name: 'auto-report', intervalMs: config.reportSampleMs };
    logger.info(`Continuous reporting every ${effectiveIntervalMs}ms (sample ${config.reportSampleMs}ms).`);
    let running = false;
    reportTimer = setInterval(async () => {
      if (fatal || running) return;
      running = true;
      try {
        await runAndSubmit(command, 'auto');
      } finally {
        running = false;
      }
    }, effectiveIntervalMs);
    if (reportTimer.unref) reportTimer.unref();
  }

  function stopReporting() {
    if (reportTimer) {
      clearInterval(reportTimer);
      reportTimer = null;
    }
  }

  // Re-reports capabilities on a fixed cadence. The ARP table, the connection
  // table, the NIC inventory and the LLDP neighbours are all in that report,
  // and they used to be sent only at start and on a WS reconnect — so on an
  // agent whose connection simply held, the server's IP↔MAC map and service
  // graph froze at the moment it connected. Skipped while disconnected (the
  // reconnect reports anyway) and after a fatal; unref'd, so it never holds
  // the process open. 0 disables it.
  function startCapabilitiesReporting() {
    stopCapabilitiesReporting();
    const intervalMs = config.capabilitiesIntervalMs;
    if (fatal || !Number.isFinite(intervalMs) || intervalMs <= 0) return;
    let running = false;
    capabilitiesTimer = setInterval(async () => {
      if (fatal || running || !client.isConnected()) return;
      running = true;
      try { await reportCapabilities(); } finally { running = false; }
    }, intervalMs);
    if (capabilitiesTimer.unref) capabilitiesTimer.unref();
  }

  function stopCapabilitiesReporting() {
    if (capabilitiesTimer) {
      clearInterval(capabilitiesTimer);
      capabilitiesTimer = null;
    }
  }

  // Drains the syslog buffer and ships one batch. A 401 is fatal; anything else
  // is non-terminal — but the drained events are NOT put back. A server that is
  // down for an hour would otherwise have the agent hold an hour of log lines in
  // memory on a host it does not own, and the receiver's own bounded buffer
  // exists precisely so this process never becomes the outage. The counters in
  // stats() record what was lost, so the gap is visible rather than silent.
  async function flushDeviceEvents() {
    if (fatal || (!syslog && !traps)) return 0;
    // Both receivers drain into ONE batch: a trap and a syslog line are the
    // same kind of row, and sending them separately would double the requests
    // for no benefit. A receiver that throws costs its own rows, not the
    // other's.
    const events = [];
    for (const [name, rx] of [['syslog', syslog], ['traps', traps]]) {
      if (!rx) continue;
      try {
        events.push(...rx.drain());
      } catch (err) {
        logger.warn(`Could not drain the ${name} buffer (${err.message}).`);
      }
    }
    if (!events.length) return 0;
    try {
      await api.postDeviceEvents(events);
      lastDeviceEventAt = Date.now();
      logger.info(`Submitted ${events.length} device event(s).`);
      emitter.emit('device-events', events.length);
      return events.length;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return 0; }
      logger.warn(`Could not submit ${events.length} device event(s) (${err.message}).`);
      reportError('device-events', err);
      return 0;
    }
  }

  // Starts the ONE device-event flush timer. Called by whichever receiver binds
  // first; the second call is a no-op, so an agent with both syslog and traps
  // runs one timer, not two racing each other over the same drain. It used to
  // live inside startSyslog, which left a trap-only agent buffering traps that
  // were never sent. The interval is syslogFlushIntervalMs for both.
  function startDeviceEventFlush() {
    if (deviceEventTimer || fatal) return;
    const intervalMs = config.syslogFlushIntervalMs;
    if (!intervalMs || intervalMs <= 0) return;
    let running = false;
    deviceEventTimer = setInterval(async () => {
      if (fatal || running) return;
      running = true;
      try {
        await flushDeviceEvents();
      } finally {
        running = false;
      }
    }, intervalMs);
    if (deviceEventTimer.unref) deviceEventTimer.unref();
  }

  function stopDeviceEventFlush() {
    if (deviceEventTimer) {
      clearInterval(deviceEventTimer);
      deviceEventTimer = null;
    }
  }

  // Binds the receiver and starts the flush timer. A bind failure is reported
  // and survived: the agent's traffic reporting and probes must keep working on
  // a host where something else already holds the port.
  async function startSyslog() {
    if (!syslog || fatal) return;
    try {
      syslogBound = typeof syslog.start === 'function' ? await syslog.start() : { injected: true };
      emitter.emit('syslog', syslogBound);
    } catch (err) {
      logger.warn(`Syslog receiver did not start (${err.message}).`);
      reportError('syslog-bind', err);
      emitter.emit('syslog', null);
      return;
    }
    startDeviceEventFlush();
  }

  // Applies the server's switch assignment. An agent whose server is too old to
  // send the key gets an empty list and polls nothing, which is exactly right.
  function applySnmpTargets(list) {
    try {
      snmpTargetCount = snmp.setTargets(list);
      // The trap allowlist and the ifIndex resolver both key on the device's
      // ADDRESS, so they are rebuilt from the same assignment. A literal IP is
      // in force immediately; a hostname keeps the addresses it resolved to
      // last time (if its name did not change) until the fresh lookup lands.
      const prevHosts = new Map(hostByDeviceId);
      const prevAddrs = new Map(addressesByDeviceId);
      hostByDeviceId.clear();
      addressesByDeviceId.clear();
      communityByDeviceId.clear();
      const toResolve = [];
      for (const d of Array.isArray(list) ? list : []) {
        if (!d || d.deviceId == null || typeof d.host !== 'string' || !d.host.trim()) continue;
        const host = d.host.trim();
        hostByDeviceId.set(d.deviceId, host);
        if (typeof d.community === 'string' && d.community && String(d.version || '2c') !== '3' && !(d.v3 && d.v3.user)) {
          communityByDeviceId.set(d.deviceId, d.community);
        }
        if (net.isIP(host)) {
          addressesByDeviceId.set(d.deviceId, new Set([host]));
        } else {
          const kept = prevHosts.get(d.deviceId) === host ? prevAddrs.get(d.deviceId) : null;
          addressesByDeviceId.set(d.deviceId, new Set(kept || []));
          toResolve.push({ deviceId: d.deviceId, host });
        }
      }
      for (const id of [...ifNamesByDeviceId.keys()]) {
        if (!hostByDeviceId.has(id)) ifNamesByDeviceId.delete(id);
      }
      if (snmpTargetCount) logger.info(`SNMP topology: polling ${snmpTargetCount} device(s).`);
      resolveTargetHosts(toResolve);
    } catch (err) {
      logger.warn(`Could not apply SNMP targets (${err.message}).`);
      snmpTargetCount = 0;
    }
  }

  // Resolves the hostname targets to addresses, off the config path: a slow
  // resolver must not hold up the monitor config. A later re-apply supersedes
  // an earlier lookup still in flight (the generation check), and a failed
  // lookup keeps what the device had, so a DNS blip does not start refusing a
  // switch's traps. Never throws; emits 'snmp-targets-resolved' when done.
  function resolveTargetHosts(items) {
    const generation = ++targetResolveGeneration;
    if (!items.length) return;
    Promise.all(items.map(async ({ deviceId, host }) => {
      try {
        const res = await lookupHost(host);
        const addrs = (Array.isArray(res) ? res : [res])
          .map((a) => (a && typeof a === 'object' ? a.address : a))
          .filter((a) => typeof a === 'string' && net.isIP(a))
          .map((a) => (a.startsWith('::ffff:') && net.isIPv4(a.slice(7)) ? a.slice(7) : a));
        if (!addrs.length) return;
        if (generation !== targetResolveGeneration || hostByDeviceId.get(deviceId) !== host) return;
        addressesByDeviceId.set(deviceId, new Set(addrs));
      } catch (err) {
        logger.warn(`Could not resolve SNMP target ${host} (${(err && err.code) || (err && err.message)}); its traps are matched on the last known address, if any.`);
      }
    })).then(() => {
      if (generation === targetResolveGeneration) emitter.emit('snmp-targets-resolved', items.length);
    }).catch(() => { /* never unhandled */ });
  }

  // Runs one poll cycle. A 401 is fatal like everywhere else; anything else is
  // non-terminal — a switch that did not answer is reported as a per-device
  // error inside the batch, not as a failure of the cycle.
  // Runs a burst and streams every sample over the WebSocket the agent already
  // holds, so the dashboard's chart draws while the measurement happens rather
  // than appearing whole at the end. A dropped frame costs one point on a
  // chart; the authoritative series is in the final reply.
  async function handleBurst(command) {
    const id = command && command.id;
    const result = await burst.run(command, {
      onSample: (sample, progress) => {
        try {
          client.send({ type: 'burst_sample', id, sample, index: progress.index, total: progress.total });
        } catch { /* the chart is a courtesy; the reply is the record */ }
      },
    });
    client.send({ type: 'command-result', id, ok: result.ok, burst: result });
    emitter.emit('burst', result);
    return result;
  }

  async function runSnmpCycle(opts) {
    if (fatal || !snmpTargetCount) return { polled: 0, failed: 0 };
    try {
      const r = await snmp.runCycle({ ...(opts || {}), onResult: rememberInterfaces });
      if (r.polled) {
        lastSnmpAt = Date.now();
        emitter.emit('snmp-topology', r);
      }
      return r;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return { polled: 0, failed: 0 }; }
      logger.warn(`SNMP topology cycle failed (${err.message}).`);
      reportError('snmp-topology', err);
      return { polled: 0, failed: 0 };
    }
  }

  // The counter cycle, on its own schedule. Separate from runSnmpCycle because
  // the two measure different things at different cadences: a forwarding table
  // is a snapshot of where things are, and a counter series' interval IS its
  // resolution.
  async function runSnmpCounterCycle(opts) {
    if (fatal || !snmpTargetCount) return { polled: 0, failed: 0 };
    try {
      const r = await snmp.runCounterCycle(opts || {});
      if (r.polled) {
        lastSnmpCounterAt = Date.now();
        emitter.emit('snmp-counters', r);
      }
      return r;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return { polled: 0, failed: 0 }; }
      logger.warn(`SNMP counter cycle failed (${err.message}).`);
      reportError('snmp-counters', err);
      return { polled: 0, failed: 0 };
    }
  }

  // Binds the trap receiver. Like syslog, a failure here is reported and
  // survived: an agent that cannot bind 1162 must keep reporting traffic,
  // running probes and polling switches.
  async function startTraps() {
    if (!traps || fatal) return;
    try {
      trapsBound = typeof traps.start === 'function' ? await traps.start() : { injected: true };
    } catch (err) {
      logger.warn(`SNMP trap receiver did not start (${err.message}).`);
      reportError('trap-bind', err);
      emitter.emit('traps', null);
      return;
    }
    // The shared flush — a no-op when syslog already started it.
    startDeviceEventFlush();
    emitter.emit('traps', trapsBound);
  }

  function stopTraps() {
    if (traps && typeof traps.stop === 'function') {
      try { traps.stop(); } catch { /* shutdown must not throw */ }
    }
    trapsBound = null;
  }

  function stopSyslog() {
    if (syslog && typeof syslog.stop === 'function') {
      try { syslog.stop(); } catch { /* shutdown must not throw */ }
    }
    syslogBound = null;
  }

  // Resolves the scheduled probe set (gateway + DNS + configured), runs each and
  // submits the batch in one POST. A 401 is fatal; other errors are non-terminal.
  // runProbe never throws, so a single bad target can't abort the cycle.
  async function runScheduledProbes() {
    if (fatal) return false;
    let specs;
    try {
      specs = await resolveTargets({
        configured: config.probeTargets,
        gateway: config.probeAutoGateway,
        dns: config.probeAutoDns,
        count: config.probeCount,
      });
    } catch (err) {
      logger.warn(`Could not resolve probe targets (${err.message}).`);
      reportError('probe-targets', err);
      return false;
    }
    if (!specs || !specs.length) return false;
    const results = [];
    for (const spec of specs.slice(0, MAX_SCHEDULED_TARGETS)) {
      results.push(await probeRunner(spec));
    }
    try {
      const response = await api.postProbeResults(results);
      logger.info(`Scheduled probes: ${results.length} target(s) submitted.`);
      emitter.emit('scheduled-probes-submitted', { results, response });
      return true;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return false; }
      // A 400 refuses the WHOLE batch — typically one result an older server
      // does not know (a probe type added after it shipped). Resubmit one by
      // one so the rest of the cycle still lands; only the refused result is
      // dropped, and it is logged by type so the gap is visible.
      if (err.status === 400 && results.length > 1) {
        return submitProbesIndividually(results);
      }
      logger.error(`Failed to submit scheduled probes: ${err.message}`);
      reportError('scheduled-probes', err);
      emitter.emit('command-error', err);
      return false;
    }
  }

  async function submitProbesIndividually(results) {
    const accepted = [];
    const refused = [];
    for (const result of results) {
      try {
        // eslint-disable-next-line no-await-in-loop
        await api.postProbeResults([result]);
        accepted.push(result);
      } catch (err) {
        if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return false; }
        refused.push({ type: result && result.type, target: result && result.target, error: err.message });
      }
    }
    if (refused.length) {
      const what = refused.map((r) => `${r.type}:${r.target}`).join(', ');
      logger.warn(`Scheduled probes: the server refused ${refused.length} result(s) (${what}); ${accepted.length} submitted one by one.`);
      reportError('scheduled-probes', new Error(`server refused ${refused.length} probe result(s): ${what}`));
    }
    emitter.emit('scheduled-probes-submitted', { results: accepted, refused, response: null });
    return accepted.length > 0;
  }

  function startScheduledProbes() {
    if (fatal) return;
    if (!config.probeIntervalMs || config.probeIntervalMs <= 0) {
      logger.info('Scheduled probes disabled (interval <= 0).');
      return;
    }
    stopScheduledProbes();
    logger.info(`Scheduled probes every ${config.probeIntervalMs}ms (gateway/DNS + ${config.probeTargets.length} configured).`);
    let running = false;
    probeTimer = setInterval(async () => {
      if (fatal || running) return;
      running = true;
      try { await runScheduledProbes(); } finally { running = false; }
    }, config.probeIntervalMs);
    if (probeTimer.unref) probeTimer.unref();
  }

  function stopScheduledProbes() {
    if (probeTimer) {
      clearInterval(probeTimer);
      probeTimer = null;
    }
  }

  client.on('open', () => {
    emitter.emit('open');
    // A connection that opened means the token was accepted, so a pause taken
    // over a 401 is over.
    resumeAfterAuth();
    // On (re)connect, re-report capabilities AND refresh config. Re-reporting
    // capabilities converges the server's stored agent version onto the running
    // one — after a self-update/restart, or when the one-shot bootstrap report
    // raced a server restart and never landed. Without this the dashboard's
    // overview keeps showing the stale version (and a phantom "update" badge)
    // even though the live agent — and the Diagnose snapshot — is newer.
    if (!fatal) {
      reportCapabilities().catch(() => {});
      loadServerConfig().catch(() => {});
      // Flush any transaction results buffered while we were offline.
      try { txManager.flush(); } catch (err) { logger.warn(`Transaction flush failed: ${err.message}`); }
    }
  });
  // Confirming an update is the agent's job, and "connected" alone is not
  // enough: a release that comes up, connects and then dies on its first real
  // work would confirm the very thing killing it. So the timer starts on the
  // first connection and only a connection that HOLDS clears the marker. Until
  // it does, the release guard counts this release's starts and rolls back.
  let confirmTimer = null;
  function armReleaseConfirmation() {
    if (confirmTimer || !releasesDir) return;
    const pending = guard.readPending(releasesDir);
    if (!pending) return; // no update waiting to prove itself
    logger.info(`Release ${pending.version} is unproven (start ${pending.attempts}); confirming after ${Math.round(confirmReleaseAfterMs / 1000)}s connected.`);
    confirmTimer = setTimeout(() => {
      confirmTimer = null;
      if (guard.confirmRelease(releasesDir)) {
        actions.log('update.confirmed', { version: pending.version });
        logger.info(`Release ${pending.version} confirmed — it held a server connection.`);
        emitter.emit('release-confirmed', pending);
      }
    }, confirmReleaseAfterMs);
    if (typeof confirmTimer.unref === 'function') confirmTimer.unref();
  }

  client.on('connected', (m) => { armReleaseConfirmation(); emitter.emit('connected', m); });
  client.on('close', (code) => emitter.emit('close', code));
  // The WS saw the 401 first (the handshake carries the token). Pause the same
  // way a REST 401 does, so nothing keeps measuring into a server that refuses
  // this agent.
  client.on('auth-rejected', ({ reason, retryInMs }) => {
    handleTokenRejected(reason);
    emitter.emit('auth-rejected', { reason, retryInMs });
  });
  // The connection was open but the peer had stopped answering. Worth surfacing:
  // it is the difference between "the network broke" and "the socket closed".
  client.on('stale', (info) => {
    actions.log('connection.stale', { staleMs: info.staleMs, serverUrl: info.serverUrl });
    emitter.emit('stale', info);
  });
  client.on('server-url', (url) => {
    logger.warn(`Server URL failover: now using ${url}.`);
    actions.log('connection.failover', { serverUrl: url });
    emitter.emit('server-url', url);
  });
  // A WS-origin fatal (e.g. 401 handshake) must fully shut the runtime down too
  // — stop reporting + mark fatal — not just re-emit, so no timers linger.
  client.on('fatal', (reason) => handleFatal(reason));

  // Snapshot of this agent's flow pipeline for the dashboard "Diagnose" action:
  // the live monitor source, the collector's receive/decode counters (read
  // WITHOUT draining them, so a diagnose never steals an interval's data), the
  // local exporter state and when we last reported. Pure read of current state.
  function buildDiagnostic() {
    const stats = currentSampler && typeof currentSampler.stats === 'function' ? currentSampler.stats() : null;
    const kind = currentSampler ? currentSampler.kind || null : null;
    return {
      agentVersion: capabilities.agentVersion,
      managed: capabilities.managed,
      source: monitorConfig.source,
      sources: capabilities.sources,
      intervalMs: effectiveIntervalMs,
      lastReportAt: lastReportAt ? new Date(lastReportAt).toISOString() : null,
      collector: stats ? { kind, ...stats } : null,
      // What is waiting to be delivered, and how old the oldest is. The
      // difference between "this agent stopped measuring" and "this agent cannot
      // get its measurements to me", answerable without host access.
      spool: typeof spool.stats === 'function' ? spool.stats() : null,
      // Which of the configured ways in it is using, so a failover is visible.
      serverUrl: typeof client.activeServerUrl === 'function' ? client.activeServerUrl() : config.serverUrl,
      hsflowd: lastHsflowdState ? { state: lastHsflowdState.state, detail: lastHsflowdState.detail || null } : null,
      // Same question as the flow pipeline, one layer over: are device events
      // arriving at all, are they being refused by the rate limit, and is the
      // buffer overflowing? Answerable from the dashboard, without host access.
      syslog: syslog && typeof syslog.stats === 'function'
        ? {
          ...syslog.stats(),
          bound: syslogBound,
          lastSubmitAt: lastDeviceEventAt ? new Date(lastDeviceEventAt).toISOString() : null,
        }
        : null,
      traps: traps && typeof traps.stats === 'function'
        ? { ...traps.stats(), bound: trapsBound }
        : null,
      // Which switches this agent polls, when each was last attempted, and
      // whether anything has been submitted. Answers "why is this switch's
      // port table empty?" from the dashboard, without host access.
      snmp: snmpTargetCount
        ? {
          ...snmp.stats(),
          lastSubmitAt: lastSnmpAt ? new Date(lastSnmpAt).toISOString() : null,
          // Reported separately: a fleet where the topology poll works and the
          // counter poll does not is a real and very different state from one
          // where neither does.
          lastCounterSubmitAt: lastSnmpCounterAt ? new Date(lastSnmpCounterAt).toISOString() : null,
        }
        : null,
    };
  }

  // Replies to a server "diagnose" command with the snapshot above, so the
  // dashboard can show, per agent, exactly where flows stop (source isn't a flow
  // source, no datagrams arriving, datagrams but no flow samples, exporter down).
  function handleDiagnose(command) {
    const diagnostic = buildDiagnostic();
    client.send({ type: 'command-result', id: command && command.id, ok: true, diagnostic });
    emitter.emit('diagnosed', diagnostic);
  }

  // Replies to a server "ping" with this agent's live identity, so the dashboard
  // can confirm the round-trip works (not just that a row says "online").
  function handlePing(command) {
    client.send({
      type: 'ack',
      id: command && command.id,
      ok: true,
      agentVersion: capabilities.agentVersion,
      sources: capabilities.sources,
      managed: capabilities.managed,
    });
    emitter.emit('pinged', command);
  }

  // Gate for the PRIVILEGED commands (update / delete / install-tool) — the three
  // that change the host rather than measure it. A command carrying a server
  // signature must verify against the pinned release key; in strict mode an
  // unsigned one is refused outright. Refusals are reported on the same channels
  // the handlers use (ack + command-result + the audit row), so the operator sees
  // a declined action rather than silence. Returns false when the command must
  // not run. `names.log` is the local action-log prefix, `names.audit` the
  // server's action name (which is 'upgrade' where the wire says 'update').
  function authorizeCommand(command, names) {
    // `rekey` does not follow the lenient default — it replaces the trust
    // anchor every later signature is checked against. See src/commandAuth.js.
    const verdict = verifyCommand(command, {
      // The command anchor, which is the release key until a vendor-authorised
      // command key has been pinned here.
      publicKey: commandKey(),
      agentId,
      strict: strictCommands,
      isRekey: names.log === 'rekey',
      allowUnsignedRekeyOverride: allowUnsignedRekey,
      replayGuard,
    });
    if (verdict.ok) {
      // The server just proved it can sign. Latch it: from now on an unsigned
      // privileged command is refused, on this run and every later one. An
      // attacker holding the socket cannot un-ring that bell.
      if (verdict.signed && !strictCommands && keys.markCommandsSigned(pinnedKeyPath)) {
        strictCommands = true;
        logger.info('This server signs privileged commands — unsigned ones are refused from now on.');
        actions.log('commands.signature-required', {});
      }
      return true;
    }
    const auditId = command && command.auditId;
    actions.log(`${names.log}.refused`, { reason: verdict.reason });
    logger.error(`Refusing ${names.log} command: ${verdict.reason}`);
    client.send({ type: 'ack', id: command && command.id, accepted: false, reason: verdict.reason });
    client.send({ type: 'command-result', id: command && command.id, ok: false, error: verdict.reason });
    if (auditId != null) client.send({ type: 'action-result', auditId, action: names.audit, ok: false, detail: verdict.reason });
    emitter.emit('command-refused', { action: names.log, reason: verdict.reason });
    return false;
  }

  // Handles a server "update" command: acknowledge immediately (so the dashboard
  // learns whether we can self-update), then — only when systemd-managed —
  // rebuild from the server's verified source bundle and restart. Docker and
  // unmanaged agents decline; their host rebuilds them.
  async function handleUpdate(command) {
    if (!authorizeCommand(command, { log: 'update', audit: 'upgrade' })) return;
    const managed = capabilities.managed;
    const auditId = command && command.auditId;
    // systemd, a Windows service and a launchd job can all be restarted onto new
    // code. Docker rebuilds its image and nothing restarts an unmanaged process,
    // so those two still decline — with the reason, so the dashboard can say why
    // instead of showing an update that quietly never happens.
    if (!isSelfUpdatable(managed)) {
      const reason = managed === 'docker' ? 'docker-managed' : 'unmanaged';
      client.send({ type: 'ack', id: command && command.id, accepted: false, runtime: managed || 'unmanaged', reason });
      actions.log('update.declined', { runtime: managed || 'unmanaged', reason });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'upgrade', ok: false, detail: reason });
      logger.warn(`Ignoring update command: runtime '${managed}' cannot be restarted onto new code.`);
      emitter.emit('update-skipped', { managed, reason });
      return;
    }
    client.send({ type: 'ack', id: command && command.id, accepted: true, runtime: managed });
    const targetVersion = (command && command.version) || null;
    const signed = !!(command && command.signature);
    actions.log('update.start', { version: targetVersion, signed });
    logger.info(`Update accepted; downloading and ${signed ? 'verifying the signed release' : 'rebuilding from the server source'}...`);
    try {
      await updater.update({
        serverUrl: config.serverUrl,
        token,
        expectedSha: command && command.sha256,
        expectedVersion: targetVersion,
        signature: command && command.signature,
        publicKey: pinnedKey,
        fetchImpl: effectiveFetch,
      });
      actions.log('update.applied', { version: targetVersion });
      logger.info('Update applied; requesting service restart.');
      // Report completion BEFORE restarting — once systemd swaps us we can't speak.
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'upgrade', ok: true, version: targetVersion });
      emitter.emit('update-applied');
      // systemd stops us (SIGTERM -> graceful exit) then starts the new code.
      // If it does NOT, we are still the old process running the old code: the
      // new version is on disk, this agent keeps reporting the old one, and the
      // dashboard would show an update that "worked" for ever. We are still alive
      // to say so, so correct the outcome we just reported.
      const restarted = updater.restart();
      if (restarted && restarted.ok === false) {
        const unit = process.env.BLUEEYE_SERVICE_NAME || 'blueeye-agent';
        const hint = managed === 'windows-service'
          ? `Restart-Service ${unit}`
          : (managed === 'launchd'
            ? `launchctl kickstart -k system/${process.env.BLUEEYE_LAUNCHD_LABEL || 'com.blueeye.agent'}`
            : `systemctl restart ${unit}`);
        const detail = `installed v${targetVersion || '?'} but the service restart failed (${restarted.detail}) — run: ${hint}`;
        actions.log('update.restart-failed', { version: targetVersion, error: restarted.detail });
        logger.error(`Self-update: ${detail}`);
        client.send({ type: 'command-result', id: command && command.id, ok: false, error: detail });
        if (auditId != null) client.send({ type: 'action-result', auditId, action: 'upgrade', ok: false, detail });
        emitter.emit('update-error', new Error(detail));
      }
    } catch (err) {
      actions.log('update.failed', { version: targetVersion, error: err.message });
      logger.error(`Self-update failed: ${err.message}`);
      client.send({ type: 'command-result', id: command && command.id, ok: false, error: err.message });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'upgrade', ok: false, detail: err.message });
      emitter.emit('update-error', err);
    }
  }

  // Handles a server "rekey" command: replace the release trust anchor this host
  // pins for signed self-updates, and keep it across restarts.
  //
  // Why the server may do this at all. The anchor is what stops a compromised
  // server pushing code this agent would run — but the agent took it from that
  // same server at install time (trust-on-first-use), and the same channel
  // already carries `delete`, which removes the agent outright. So accepting a
  // rekey over the authenticated link is no weaker than what is already
  // accepted there, and it is the only way to recover a fleet whose server lost
  // its signing key: there is no shell on these hosts. When the server CAN still
  // sign, the command carries a commandSignature made with the key being
  // replaced — a proper rotation, verified by authorizeCommand below — and
  // BLUEEYE_REQUIRE_SIGNED_COMMANDS=1 makes that mandatory.
  //
  // Not a restart: the new anchor is applied in memory, so the update that
  // usually follows it verifies immediately, and monitoring never stops.
  // Records what the vendor authorised, which also LATCHES this agent: from
  // here on a rekey without a vendor authorisation is refused. Best-effort on
  // the write — a failure means the latch is not yet set, which only ever asks
  // for more proof later, never less.
  function recordVendorTrust(verdict) {
    keys.writeTrustState(pinnedKeyPath, {
      sequence: verdict.sequence,
      licenseId: verdict.licenseId,
      customerId: verdict.customerId,
      // The fingerprint is recorded under the purpose it was authorised for,
      // so a command-key rotation never overwrites what this agent believes
      // about its release anchor.
      ...(verdict.purpose === 'command'
        ? { commandFingerprint: verdict.fingerprint }
        : { fingerprint: verdict.fingerprint }),
    });
  }

  async function handleRekey(command) {
    const auditId = command && command.auditId;
    // WHICH anchor this rekey replaces. `release` is the default, because that
    // is what every rekey meant before there were two and what an older server
    // still sends.
    //
    // The field is `keyPurpose`, NOT `purpose`: `purpose` is already taken on a
    // signed command and says what the SIGNATURE is for (always 'command' on a
    // rekey, since a rekey IS a command). Reusing it here read as "this is a
    // command-key rekey" on every signed rekey ever sent, which would have
    // written the release key into the command slot and left the release anchor
    // untouched — the kind of bug two meanings for one field is for.
    const purpose = command && command.keyPurpose === 'command' ? 'command' : 'release';

    // What this host has already accepted from the vendor. `vendorRooted` is a
    // one-way latch: once a vendor-authorised key has been accepted here,
    // nothing else is ever accepted again, and no server can clear it.
    const trustState = keys.readTrustState(pinnedKeyPath);

    // The vendor's authorisation, if the server sent one. This is the ONLY
    // check that can accept a key this agent has never seen: the signature is
    // the vendor's, over bytes the server can neither forge nor edit, so a
    // server that has been taken over cannot manufacture one.
    let vendor = null;
    if (command && command.vendorProof) {
      const verdict = verifyTrustProof({
        proof: command.vendorProof,
        offeredKey: command.publicKey,
        purpose,
        expected: {
          licenseId: trustState.licenseId,
          customerId: trustState.customerId,
          sequence: trustState.sequence,
        },
      });
      if (!verdict.ok) {
        // Fail closed and say which step failed — these codes are what an
        // operator reads when a rekey does not land.
        const reason = `refusing rekey: ${verdict.code} — ${verdict.detail}`;
        actions.log('rekey.refused', { code: verdict.code, reason: verdict.detail });
        logger.error(reason);
        client.send({ type: 'ack', id: command && command.id, accepted: false, reason });
        client.send({ type: 'command-result', id: command && command.id, ok: false, error: reason });
        if (auditId != null) client.send({ type: 'action-result', auditId, action: 'rekey', ok: false, detail: reason });
        emitter.emit('rekey-error', new Error(reason));
        return;
      }
      vendor = verdict;
    } else if (trustState.vendorRooted) {
      // Latched. A rekey signed with the key being replaced was the migration
      // path; once the vendor has spoken for this host, that path is closed —
      // otherwise an attacker who obtained the old private key could still
      // re-anchor the fleet.
      const reason = 'refusing rekey: this agent requires a vendor-signed authorisation, and the command carried none. '
        + 'The server must obtain a licence proof authorising this key (its administrator generates the key, '
        + 'the vendor approves the fingerprint) before the fleet will accept it.';
      actions.log('rekey.refused', { code: 'LICENSE_PROOF_INVALID', reason: 'no vendor proof' });
      logger.error(reason);
      client.send({ type: 'ack', id: command && command.id, accepted: false, reason });
      client.send({ type: 'command-result', id: command && command.id, ok: false, error: reason });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'rekey', ok: false, detail: reason });
      emitter.emit('rekey-error', new Error(reason));
      return;
    }

    // A vendor authorisation stands on its own: it proves more than a signature
    // made with the key being replaced ever could, and requiring both would
    // make the one case this exists for — recovering a fleet whose server lost
    // its signing key — impossible again. Without one, the old rules apply.
    if (!vendor && !authorizeCommand(command, { log: 'rekey', audit: 'rekey' })) return;

    const parsed = keys.validatePublicKey(command && command.publicKey);
    if (!parsed.ok) {
      const reason = `refusing rekey: ${parsed.reason}`;
      actions.log('rekey.refused', { reason: parsed.reason });
      logger.error(reason);
      client.send({ type: 'ack', id: command && command.id, accepted: false, reason });
      client.send({ type: 'command-result', id: command && command.id, ok: false, error: reason });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'rekey', ok: false, detail: reason });
      emitter.emit('rekey-error', new Error(reason));
      return;
    }
    client.send({ type: 'ack', id: command && command.id, accepted: true, runtime: capabilities.managed || 'unmanaged' });
    // Which anchor is being compared and replaced. The release key is also the
    // environment-baked one the systemd drop-in carries; the command key is
    // file-only, so there is no unit to keep in step for it.
    const current = purpose === 'command' ? pinnedCommandKey : pinnedKey;
    const targetPath = keys.keyPathFor(pinnedKeyPath, purpose);
    if (current && current.trim() === parsed.pem.trim()) {
      // Already the key we trust. Still record the authorisation: a re-sent
      // proof with a HIGHER sequence is how the anti-rollback floor rises
      // without the key itself changing.
      if (vendor) recordVendorTrust(vendor);
      actions.log('rekey.unchanged', { purpose, fingerprint: parsed.fingerprint });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'rekey', ok: true, detail: `unchanged (${parsed.fingerprint.slice(0, 12)}…)` });
      emitter.emit('rekeyed', { purpose, fingerprint: parsed.fingerprint, changed: false });
      return;
    }
    try {
      keys.writePinnedKey(targetPath, parsed.pem);
      let unit = { ok: true, path: null };
      if (purpose === 'command') {
        pinnedCommandKey = parsed.pem;
      } else {
        pinnedKey = parsed.pem;
        // Best-effort: keep the unit's environment in step, so the key a person
        // reads in the unit is the key the agent uses. A failure here is not a
        // failed rekey — the stored file is what the agent reads at startup.
        // Only the release key: the unit has no variable for the command key,
        // deliberately, because an env var is a way to introduce one without a
        // vendor authorisation.
        unit = keys.syncSystemdDropIn(parsed.pem);
      }
      // Written AFTER the key, so a crash between the two leaves the agent
      // asking for more proof next time, never less.
      if (vendor) recordVendorTrust(vendor);
      actions.log('rekey.applied', {
        purpose,
        fingerprint: parsed.fingerprint,
        vendor: vendor ? { sequence: vendor.sequence, license: vendor.licenseId } : null,
        unit: unit.ok ? unit.path : null,
        unitReason: unit.ok ? null : unit.reason,
      });
      logger.warn(`AGENT_TRUST_ACCEPTED: ${purpose} anchor replaced (sha256 ${parsed.fingerprint.slice(0, 12)}…)`
        + `${vendor ? `, vendor-authorised seq ${vendor.sequence}` : ' (no vendor authorisation — legacy path)'}`
        + `${unit.ok ? '' : ` — systemd drop-in not updated: ${unit.reason}`}`);
      if (auditId != null) {
        client.send({ type: 'action-result', auditId, action: 'rekey', ok: true, detail: `pinned ${parsed.fingerprint.slice(0, 12)}…` });
      }
      client.send({ type: 'command-result', id: command && command.id, ok: true, purpose, fingerprint: parsed.fingerprint });
      emitter.emit('rekeyed', { purpose, fingerprint: parsed.fingerprint, changed: true });
    } catch (err) {
      actions.log('rekey.failed', { error: err.message });
      logger.error(`Rekey failed: ${err.message}`);
      client.send({ type: 'command-result', id: command && command.id, ok: false, error: err.message });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'rekey', ok: false, detail: err.message });
      emitter.emit('rekey-error', err);
    }
  }

  // Handles a server "delete" command: remove this agent from the host. The agent
  // securely wipes its token and runs the shipped uninstall.sh (detached) to stop
  // its service and delete its files. It reports 'completed' to the server FIRST
  // (so the server can finalise the audit row + drop the agent record) because
  // afterwards it has neither token nor process. Docker agents decline (the host
  // removes the container).
  async function handleDelete(command) {
    if (!authorizeCommand(command, { log: 'delete', audit: 'delete' })) return;
    const managed = capabilities.managed;
    const auditId = command && command.auditId;
    if (managed === 'docker') {
      client.send({ type: 'ack', id: command && command.id, accepted: false, runtime: 'docker', reason: 'docker-managed' });
      actions.log('delete.declined', { runtime: 'docker' });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'delete', ok: false, detail: 'docker-managed' });
      logger.warn("Ignoring delete command: runtime 'docker' removes itself via the host.");
      emitter.emit('delete-skipped', { reason: 'docker-managed' });
      return;
    }
    client.send({ type: 'ack', id: command && command.id, accepted: true, runtime: managed || 'unmanaged' });
    actions.log('delete.start', {});
    logger.warn('Delete accepted; wiping token and removing this agent from the host.');
    // Stop an exporter WE provisioned before removing ourselves, so the delete
    // doesn't orphan a root daemon exporting sFlow to a dead collector.
    // Best-effort: an exporter failure must never block the delete itself.
    try {
      if (hsflowdManaged || (await managedByThisAgent())) {
        const r = await hsflowd.disable();
        hsflowdManaged = false;
        actions.log('delete.hsflowd-disabled', { state: r && r.state });
        logger.info(`Stopped the agent-managed hsflowd exporter (${(r && r.state) || 'unknown'}).`);
      }
    } catch { /* best-effort */ }
    try {
      deleter.wipeToken();
      actions.log('delete.token-wiped', {});
      // Tell the server we're done BEFORE the detached removal stops us.
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'delete', ok: true });
      emitter.emit('delete-applied');
      deleter.remove(); // detached: sleeps briefly, then stops the service + removes files
    } catch (err) {
      actions.log('delete.failed', { error: err.message });
      logger.error(`Self-delete failed: ${err.message}`);
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'delete', ok: false, detail: err.message });
      emitter.emit('delete-error', err);
    }
  }

  // Handles a server "install-tool" command: install a missing diagnostic tool
  // (e.g. traceroute) from the host's package manager, then report the outcome.
  // The agent only ever installs tools on its OWN allowlist (toolInstaller) — a
  // tool not on the list is refused regardless of what the server asked for, so
  // a compromised server can't push an arbitrary package. Docker hosts decline
  // (the image owns its packages). systemd/unmanaged proceed with whatever
  // privilege the agent already runs with; a genuine "needs root" surfaces as a
  // distinct failure rather than silently doing nothing.
  async function handleInstallTool(command) {
    if (!authorizeCommand(command, { log: 'install-tool', audit: 'install-tool' })) return;
    const managed = capabilities.managed;
    const auditId = command && command.auditId;
    const tool = (command && command.tool) || '';
    if (managed === 'docker') {
      client.send({ type: 'ack', id: command && command.id, accepted: false, runtime: 'docker', reason: 'docker-managed' });
      actions.log('install-tool.declined', { runtime: 'docker', tool });
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'install-tool', ok: false, tool, detail: 'docker-managed' });
      logger.warn("Ignoring install-tool command: runtime 'docker' manages its own packages.");
      emitter.emit('install-tool-skipped', { reason: 'docker-managed', tool });
      return;
    }
    client.send({ type: 'ack', id: command && command.id, accepted: true, runtime: managed || 'unmanaged' });
    actions.log('install-tool.start', { tool });
    logger.info(`Install-tool accepted; installing '${tool}'...`);
    try {
      const result = await installer.installTool({ tool });
      if (result.ok) {
        actions.log('install-tool.applied', { tool, package: result.package, manager: result.manager });
        logger.info(`Installed '${tool}' (${result.package} via ${result.manager}).`);
        if (auditId != null) client.send({ type: 'action-result', auditId, action: 'install-tool', ok: true, tool, package: result.package, manager: result.manager });
        emitter.emit('install-tool-applied', result);
      } else {
        actions.log('install-tool.failed', { tool, error: result.detail });
        logger.warn(`Install of '${tool}' failed: ${result.detail}`);
        if (auditId != null) client.send({ type: 'action-result', auditId, action: 'install-tool', ok: false, tool, detail: result.detail });
        emitter.emit('install-tool-error', result);
      }
    } catch (err) {
      actions.log('install-tool.failed', { tool, error: err.message });
      logger.error(`Install of '${tool}' errored: ${err.message}`);
      if (auditId != null) client.send({ type: 'action-result', auditId, action: 'install-tool', ok: false, tool, detail: err.message });
      emitter.emit('install-tool-error', err);
    }
  }

  // Runs an active speed test against the server and submits the result. A 401
  // is fatal; other errors are surfaced but non-terminal.
  async function runSpeedtestAndSubmit(command) {
    try {
      const bytes = Number.isInteger(command && command.bytes) && command.bytes > 0 ? command.bytes : undefined;
      const result = await runSpeedtest({ serverUrl: config.serverUrl, token, bytes, fetchImpl: effectiveFetch });
      const response = await api.postSpeedtest(result);
      logger.info(`Speed test: down ${result.downMbps ?? '?'} / up ${result.upMbps ?? '?'} Mbps.`);
      emitter.emit('speedtest-submitted', { result, response });
      return true;
    } catch (err) {
      if (err.code === 'TOKEN_REJECTED') { handleTokenRejected(); return false; }
      logger.error(`Speed test failed: ${err.message}`);
      reportError('speedtest', err);
      emitter.emit('command-error', err);
      return false;
    }
  }

  // Read-only evidence collectors (Fase 6). Each returns bounded text from a
  // read-only source the agent already has — /proc counters, the neighbour table,
  // its own live state. No writes, no new SNMP OID scope. Best-effort per item.
  const evidenceCollectors = {
    'agent.state': async () => [
      `connected: ${client.isConnected() ? 'yes' : 'no'}`,
      `lastReportAt: ${lastReportAt ? new Date(lastReportAt).toISOString() : 'never'}`,
      `sources: ${(capabilities.sources || []).join(', ') || 'none'}`,
      `monitorSource: ${monitorConfig && monitorConfig.source ? monitorConfig.source : 'unknown'}`,
      `agentVersion: ${capabilities.agentVersion || 'unknown'}`,
    ].join('\n'),
    'iface.counters': async () => fs.readFileSync('/proc/net/dev', 'utf8'),
    'arp.table': async () => fs.readFileSync('/proc/net/arp', 'utf8'),
    'snmp.reads': async () => (monitorConfig && monitorConfig.source === 'snmp'
      ? `SNMP collector target: ${(monitorConfig.snmp && monitorConfig.snmp.host) || 'configured'} (read-only counters already polled by the collector).`
      : 'SNMP not configured on this agent.'),
  };

  // Handles a read-only evidence-snapshot command. Verifies the server signature
  // (when the release key is configured — reusing the release verifier), enforces
  // the agent's OWN read-only allowlist per item, collects, and replies. Never
  // performs a write action; a non-allowlisted item is refused.
  async function handleEvidence(command) {
    // Defense in depth: if the command is signed AND we have the pinned key, it
    // MUST verify or we refuse the whole snapshot (fail closed).
    if (command && command.signature && pinnedKey) {
      const payload = {
        name: command.name, snapshotId: command.snapshotId, clusterId: command.clusterId,
        commandSetVersion: command.commandSetVersion, items: command.items,
      };
      // The purpose is rebuilt only when the server sent one, so a snapshot
      // from an older server still verifies over the bytes it actually signed.
      if (command.purpose != null) payload.purpose = command.purpose;
      if (!verifyManifest(payload, command.signature, pinnedKey)) {
        actions.log('evidence.refused', { reason: 'bad-signature', snapshotId: command.snapshotId });
        client.send({ type: 'command-result', id: command.id, ok: false, error: 'evidence command signature verification failed' });
        return;
      }
      // …and a signature made for anything OTHER than evidence is refused, even
      // though it verifies: this path reads files off the host, and the one
      // thing standing between it and a captured release signature is the
      // payload shape.
      if (!purposeOk(payload, 'evidence')) {
        actions.log('evidence.refused', { reason: 'wrong-purpose', snapshotId: command.snapshotId });
        client.send({ type: 'command-result', id: command.id, ok: false, error: `this signature is not for an evidence request (purpose: ${payload.purpose})` });
        return;
      }
    }
    const collector = createEvidenceCollector({ collectors: evidenceCollectors });
    const items = await collector.collect(command && command.items);
    actions.log('evidence.capture', { snapshotId: command && command.snapshotId, items: items.map((i) => ({ name: i.name, status: i.status })) });
    client.send({
      type: 'command-result', id: command && command.id, ok: true,
      evidence: { commandSetVersion: command && command.commandSetVersion, items },
    });
    emitter.emit('evidence-captured', { snapshotId: command && command.snapshotId, items });
  }

  // The dispatcher below is `async`, and an async listener on an EventEmitter
  // has nowhere to put a rejection: it becomes an unhandled rejection, which on
  // a bare Node process is an exit. One handler that forgets an internal
  // try/catch would therefore take the whole agent down — from a host where
  // nobody is watching, so the only symptom is a gap in the data.
  //
  // dispatchCommand() holds the routing; this wrapper owns the failure. A
  // handler that throws costs its own command an error reply, not the agent.
  client.on('command', (command) => {
    Promise.resolve()
      .then(() => dispatchCommand(command))
      .catch((err) => {
        logger.error(`Command handler failed: ${err && err.message}`);
        // Just enough to name the command in the local trail. Deliberately not
        // command.js's verbOf(): that module's exports are swept by the gate as
        // the recogniser set, and a parser is not a recogniser.
        const verb = (command && typeof command === 'object' && (command.name || command.action || command.type))
          || (typeof command === 'string' ? command : '')
          || 'unknown';
        actions.log('command.failed', { verb: String(verb).slice(0, 48), reason: err && err.message });
        // Tell the server, so the dashboard shows a failed action instead of a
        // request that silently never completed. Best-effort: the socket may be
        // exactly what just broke.
        try {
          client.send({ type: 'command-result', id: command && command.id, ok: false, error: `handler failed: ${err && err.message}` });
          if (command && command.auditId != null) {
            client.send({ type: 'action-result', auditId: command.auditId, ok: false, detail: `handler failed: ${err && err.message}` });
          }
        } catch { /* the channel is gone; the log above is the record */ }
        emitter.emit('command-failed', { command, error: err });
      });
  });

  async function dispatchCommand(command) {
    if (isPingCommand(command)) {
      handlePing(command);
      return;
    }
    if (isEvidenceCommand(command)) {
      await handleEvidence(command);
      return;
    }
    if (isDiagnoseCommand(command)) {
      handleDiagnose(command);
      return;
    }
    if (isUpdateCommand(command)) {
      await handleUpdate(command);
      return;
    }
    if (isRekeyCommand(command)) {
      logger.info('Received rekey command; replacing the release trust anchor.');
      await handleRekey(command);
      return;
    }
    if (isDeleteCommand(command)) {
      await handleDelete(command);
      return;
    }
    if (isInstallToolCommand(command)) {
      logger.info(`Received install-tool command (${command.tool}).`);
      await handleInstallTool(command);
      return;
    }
    if (isSpeedtestCommand(command)) {
      logger.info('Received speed-test command; measuring throughput...');
      await runSpeedtestAndSubmit(command);
      return;
    }
    if (isRunProbeCommand(command)) {
      logger.info(`Received run-probe command (${command.probe.type}).`);
      await runProbeAndSubmit(command.probe);
      return;
    }
    if (isStopBurstCommand(command)) {
      const wasRunning = burst.cancel();
      logger.info(wasRunning ? 'Received stop-burst; stopping at the next tick.' : 'Received stop-burst; nothing running.');
      client.send({ type: 'command-result', id: command && command.id, ok: true, stopped: wasRunning });
      return;
    }
    if (isBurstCommand(command)) {
      logger.info(`Received burst command (${command.target}).`);
      await handleBurst(command);
      return;
    }
    if (isRunTransactionCommand(command)) {
      const testId = transactionIdOf(command);
      logger.info(`Received run-transaction command (test ${testId}${command.capture ? ', with capture' : ''}).`);
      const out = await txManager.runNow(testId, { capture: command.capture === true });
      client.send({ type: 'command-result', id: command && command.id, ok: !!out.ok, transaction: out });
      return;
    }
    if (isPollSnmpCommand(command)) {
      logger.info('Received poll-snmp command; refreshing the assignment, then polling assigned switches now.');
      // "Poll now" is pressed right after a device was added or moved to this
      // agent, and the assignment used to be read only on (re)connect — so it
      // polled the OLD list, often nothing, while the server had already said
      // 202. Re-read it first, bounded, and poll with what we have if that fails.
      const refreshed = await loadServerConfigWithin(
        config.pollConfigTimeoutMs > 0 ? config.pollConfigTimeoutMs : POLL_CONFIG_TIMEOUT_MS, { force: false });
      if (fatal) return;
      // Both cycles, because "poll now" from the dashboard means the whole
      // device, not the half of it this command happened to be written for.
      // waitIfRunning: a cycle already in flight (a timer tick, or a second
      // Poll now) is waited for, then this one runs — never "0 polled, skipped".
      const r = await runSnmpCycle({ force: true, waitIfRunning: true });
      const c = await runSnmpCounterCycle({ force: true, waitIfRunning: true });
      const requested = command && command.deviceId != null ? command.deviceId : null;
      const result = {
        type: 'command-result',
        id: command && command.id,
        ok: true,
        // How many devices this agent is assigned and how many answered, so an
        // empty assignment is visible instead of a silent success.
        devices: snmpTargetCount,
        polled: r.polled || 0,
        failed: r.failed || 0,
        configRefreshed: !!refreshed.ok,
        snmp: r,
        counters: c,
      };
      if (requested != null) result.deviceAssigned = hostByDeviceId.has(requested);
      if (!snmpTargetCount) result.detail = 'no SNMP devices are assigned to this agent';
      else if (requested != null && !result.deviceAssigned) result.detail = `device ${requested} is not assigned to this agent`;
      if (result.detail) logger.warn(`poll-snmp: ${result.detail}.`);
      client.send(result);
      emitter.emit('poll-snmp', result);
      return;
    }
    if (isRunDiscoveryCommand(command)) {
      logger.info('Received run-discovery command; sweeping configured scope.');
      await runDiscoveryAndSubmit(command.discovery);
      return;
    }
    if (!isRunTestCommand(command)) {
      logger.warn(`Ignoring unrecognised command: ${JSON.stringify(command)}`);
      emitter.emit('command-ignored', command);
      return;
    }
    logger.info('Received run-test command; measuring traffic...');
    await runAndSubmit(command, 'command');
  }

  return {
    agentId,
    start() {
      fatal = false;
      client.start();
      // Bootstrap (capabilities + config) runs async; don't block the caller.
      (async () => {
        await reportCapabilities();
        if (fatal) return;
        await loadServerConfig();
        if (fatal) return;
        startReporting();
        startScheduledProbes();
        await startSyslog();
        await startTraps();
        // The tick only asks which devices are due; the per-device interval
        // decides what is actually polled. Each tick runs the runtime's own
        // cycle wrapper — the same one poll-snmp uses — so a scheduled cycle
        // feeds the interface-name hook and a 401 on its submit is fatal here
        // like on every other REST call.
        snmp.start({ tickMs: 30000, cycle: () => runSnmpCycle() });
        // The counter tick is faster than the topology one, because a counter
        // series' interval is its resolution: a five-minute sample cannot show
        // a two-minute error burst at all. It only asks which devices are due.
        snmp.startCounters({ tickMs: 15000, cycle: () => runSnmpCounterCycle() });
        startCapabilitiesReporting();
        startConfigRefresh();
        // Start running any persisted transaction tests (server pushes fresh
        // config on connect, which replaces these).
        try { txManager.start(); } catch (err) { logger.warn(`Transaction manager start failed: ${err.message}`); }
      })();
    },
    stop() {
      if (confirmTimer) { clearTimeout(confirmTimer); confirmTimer = null; }
      stopReporting();
      stopCapabilitiesReporting();
      stopConfigRefresh();
      stopScheduledProbes();
      stopDeviceEventFlush();
      stopSyslog();
      stopTraps();
      burst.cancel();
      snmp.stop();
      txManager.stop();
      if (currentSampler && typeof currentSampler.stop === 'function') currentSampler.stop();
      client.stop();
    },
    // Exposed for tests / manual triggering.
    reportNow: () => runAndSubmit({ name: 'auto-report', intervalMs: config.reportSampleMs }, 'manual'),
    runScheduledProbesNow: () => runScheduledProbes(),
    flushDeviceEventsNow: () => flushDeviceEvents(),
    runSnmpCycleNow: (opts) => runSnmpCycle({ force: true, ...(opts || {}) }),
    runSnmpCounterCycleNow: (opts) => runSnmpCounterCycle({ force: true, ...(opts || {}) }),
    runBurstNow: (spec) => handleBurst(spec),
    runTransactionNow: (testId, opts) => txManager.runNow(testId, opts || {}),
    refreshConfigNow: () => loadServerConfig({ force: false }),
    getMonitorConfig: () => monitorConfig,
    getHsflowdState: () => lastHsflowdState,
    getDiagnostic: () => buildDiagnostic(),
    on: emitter.on.bind(emitter),
    once: emitter.once.bind(emitter),
  };
}

module.exports = { createAgentRuntime };
