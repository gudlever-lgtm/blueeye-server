'use strict';

const fs = require('fs');

// Parses the contents of /proc/net/dev into per-interface counters.
// Column layout after "iface:": rx = bytes packets errs drop fifo frame
// compressed multicast (0-7), tx = bytes packets errs drop fifo colls carrier
// compressed (8-15). So rxBytes=col[0], rxErrors=col[2], txBytes=col[8], etc.
function parseProcNetDev(text) {
  const result = {};
  for (const line of String(text).split('\n')) {
    const match = line.match(/^\s*([^:]+):\s*(.*)$/);
    if (!match) continue;
    const iface = match[1].trim();
    const cols = match[2].trim().split(/\s+/).map(Number);
    if (cols.length < 16) continue;
    result[iface] = {
      rxBytes: cols[0],
      rxPackets: cols[1],
      rxErrors: cols[2],
      rxDrop: cols[3],
      txBytes: cols[8],
      txPackets: cols[9],
      txErrors: cols[10],
      txDrop: cols[11],
      // The four that say WHICH kind of error it was. `frame` counts frames
      // that failed alignment/length checks — on most drivers it is where
      // CRC/alignment damage lands, i.e. cabling or a duplex mismatch seen from
      // the FULL-duplex end. `fifo` is the NIC's own ring overrunning (the host
      // is too slow, not the wire). `colls` and `carrier` only move on a
      // half-duplex or failing link: a switched full-duplex port never collides.
      rxFifo: cols[4],
      rxFrame: cols[5],
      txColls: cols[13],
      txCarrier: cols[14],
    };
  }
  return result;
}

function defaultReadProc() {
  return fs.readFileSync('/proc/net/dev', 'utf8');
}

// Best-effort link state + speed for an interface, from sysfs. Returns nulls if
// unavailable (virtual/down interfaces, non-Linux). Async so it never blocks the
// event loop during continuous reporting. Injectable for tests.
async function defaultReadIfaceMeta(iface) {
  let operStatus = null;
  let speedMbps = null;
  let duplex = null;
  try { operStatus = (await fs.promises.readFile(`/sys/class/net/${iface}/operstate`, 'utf8')).trim() || null; } catch { /* n/a */ }
  try {
    const s = Number((await fs.promises.readFile(`/sys/class/net/${iface}/speed`, 'utf8')).trim());
    if (Number.isFinite(s) && s > 0) speedMbps = s;
  } catch { /* speed unreadable for many ifaces */ }
  // full | half | unknown. The kernel reports what the link NEGOTIATED (or was
  // forced to); "half" on a switched port is the half of a duplex mismatch this
  // host can see. Reading it fails (EINVAL) on a link that is down and on most
  // virtual interfaces — that is null, never a guess.
  try { duplex = parseDuplex(await fs.promises.readFile(`/sys/class/net/${iface}/duplex`, 'utf8')); } catch { /* n/a */ }
  return { operStatus, speedMbps, duplex };
}

function parseDuplex(text) {
  const v = String(text == null ? '' : text).trim().toLowerCase();
  return v === 'full' || v === 'half' || v === 'unknown' ? v : null;
}

function snapshot(readProc) {
  try {
    return parseProcNetDev(readProc());
  } catch {
    return {};
  }
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Cap on the per-interface list in a snapshot. The server rejects any single
// result over 64 KiB, and a docker/k8s host can carry hundreds of (mostly
// virtual) veth interfaces — without a cap one such host loses ALL traffic
// reporting to permanent 400s. The busiest interfaces are kept (sorted by
// rx+tx bytes over the window); `totals` still cover every interface, and the
// snapshot says how many entries were left out (`interfacesOmitted`).
const MAX_INTERFACES = 64;

// Turns two cumulative-counter snapshots (keyed by interface name, same shape
// as parseProcNetDev's return value) `elapsedSec` apart into the per-interface
// delta + rate report. Pulled out of sampleTraffic so other platforms' traffic
// sources (e.g. trafficMonitorWin.js) can feed it counters from a different
// origin while reusing this computation unchanged.
async function buildSnapshot(first, second, {
  intervalMs,
  elapsedSec,
  includeLoopback = false,
  readIfaceMeta = defaultReadIfaceMeta,
  maxInterfaces = MAX_INTERFACES,
} = {}) {
  const entries = [];
  const totals = { rxBytes: 0, txBytes: 0, rxPackets: 0, txPackets: 0, rxErrors: 0, txErrors: 0, rxDrop: 0, txDrop: 0 };
  const delta = (a, b, k) => Math.max((a[k] || 0) - (b[k] || 0), 0);
  // The error-detail counters are not reported by every source (Windows and an
  // older parse have none), and "not measured" must not read as "zero errors",
  // so a counter missing from either side is null rather than 0.
  const optDelta = (a, b, k) => (Number.isFinite(a[k]) && Number.isFinite(b[k]) ? Math.max(a[k] - b[k], 0) : null);

  for (const iface of Object.keys(second)) {
    if (!includeLoopback && iface === 'lo') continue;
    if (!first[iface]) continue;
    const rxBytes = delta(second[iface], first[iface], 'rxBytes');
    const txBytes = delta(second[iface], first[iface], 'txBytes');
    const rxPackets = delta(second[iface], first[iface], 'rxPackets');
    const txPackets = delta(second[iface], first[iface], 'txPackets');
    const rxErrors = delta(second[iface], first[iface], 'rxErrors');
    const txErrors = delta(second[iface], first[iface], 'txErrors');
    const rxDrop = delta(second[iface], first[iface], 'rxDrop');
    const txDrop = delta(second[iface], first[iface], 'txDrop');
    totals.rxBytes += rxBytes; totals.txBytes += txBytes;
    totals.rxPackets += rxPackets; totals.txPackets += txPackets;
    totals.rxErrors += rxErrors; totals.txErrors += txErrors;
    totals.rxDrop += rxDrop; totals.txDrop += txDrop;
    entries.push({
      iface,
      rxBytes,
      txBytes,
      rxPackets,
      txPackets,
      rxBytesPerSec: Math.round(rxBytes / elapsedSec),
      txBytesPerSec: Math.round(txBytes / elapsedSec),
      rxErrors,
      txErrors,
      rxDrop,
      txDrop,
      rxFrameErrors: optDelta(second[iface], first[iface], 'rxFrame'),
      rxFifoErrors: optDelta(second[iface], first[iface], 'rxFifo'),
      txCollisions: optDelta(second[iface], first[iface], 'txColls'),
      txCarrierErrors: optDelta(second[iface], first[iface], 'txCarrier'),
    });
  }

  // Cap AFTER totals so omitted interfaces still count there, and BEFORE the
  // sysfs meta reads so a veth farm doesn't cost hundreds of file reads per
  // sample. Order is unchanged when under the cap.
  let interfacesOmitted = 0;
  if (entries.length > maxInterfaces) {
    entries.sort((a, b) => (b.rxBytes + b.txBytes) - (a.rxBytes + a.txBytes));
    interfacesOmitted = entries.length - maxInterfaces;
    entries.length = maxInterfaces;
  }

  const interfaces = [];
  for (const entry of entries) {
    const meta = await readIfaceMeta(entry.iface);
    interfaces.push({
      ...entry,
      operStatus: meta.operStatus,
      speedMbps: meta.speedMbps,
      duplex: meta.duplex === undefined ? null : meta.duplex,
    });
  }

  return {
    intervalMs,
    elapsedSec: Math.round(elapsedSec * 1000) / 1000,
    interfaces,
    ...(interfacesOmitted ? { interfacesOmitted } : {}),
    totals: {
      ...totals,
      rxBytesPerSec: Math.round(totals.rxBytes / elapsedSec),
      txBytesPerSec: Math.round(totals.txBytes / elapsedSec),
    },
  };
}

// Samples network traffic by reading /proc/net/dev twice `intervalMs` apart and
// computing per-interface deltas and rates. Counters are injectable for tests.
async function sampleTraffic({
  readProc = defaultReadProc,
  intervalMs = 1000,
  sleepFn = sleep,
  now = () => Date.now(),
  includeLoopback = false,
  readIfaceMeta = defaultReadIfaceMeta,
  maxInterfaces = MAX_INTERFACES,
} = {}) {
  const t0 = now();
  const first = snapshot(readProc);
  await sleepFn(intervalMs);
  const t1 = now();
  const second = snapshot(readProc);
  const elapsedSec = Math.max((t1 - t0) / 1000, 0.001);
  return buildSnapshot(first, second, { intervalMs, elapsedSec, includeLoopback, readIfaceMeta, maxInterfaces });
}

module.exports = { parseProcNetDev, parseDuplex, snapshot, sampleTraffic, buildSnapshot, defaultReadIfaceMeta, MAX_INTERFACES };
