'use strict';

// Decodes the start of a sampled raw packet (Ethernet II + IPv4/IPv6 + TCP/UDP)
// far enough to extract the L3/L4 5-tuple. sFlow ships the first N bytes of the
// actual frame (header_protocol = 1 means Ethernet/ISO88023), so unlike NetFlow
// we parse the packet ourselves. Returns a flow-ish record or null if it isn't
// an IP/TCP/UDP packet we can read.
const { PROTO_NAMES } = require('../netflow/fields');
const { ipv4, ipv6 } = require('../netflow/ip');

const ETH_HDR = 14;
const ETHERTYPE_IPV4 = 0x0800;
const ETHERTYPE_IPV6 = 0x86dd;
const ETHERTYPE_VLAN = 0x8100;
const ETHERTYPE_QINQ = 0x88a8;

function mac(buf, o) {
  const parts = [];
  for (let i = 0; i < 6; i += 1) parts.push(buf[o + i].toString(16).padStart(2, '0'));
  return parts.join(':');
}

// Reads L4 ports for TCP(6)/UDP(17); other protocols get ports 0.
function readPorts(buf, o, protocol, end) {
  if ((protocol === 6 || protocol === 17) && o + 4 <= end) {
    return { srcPort: buf.readUInt16BE(o), dstPort: buf.readUInt16BE(o + 2) };
  }
  return { srcPort: 0, dstPort: 0 };
}

// header = the sampled raw bytes (Buffer). frameLength = the original (un-
// sampled) frame length reported by sFlow, used to scale bytes accurately.
function decodeSampledHeader(header, frameLength) {
  if (!Buffer.isBuffer(header) || header.length < ETH_HDR + 20) return null;

  let etherType = header.readUInt16BE(12);
  let l3 = ETH_HDR;
  // One 802.1Q tag (0x8100), or the outer tag of a QinQ pair (0x88a8): the
  // VLAN id is the low 12 bits of the TCI. The tag is read, not just skipped —
  // "which VLAN" is the first question about a sampled frame on a trunk.
  // 0 (priority-only tag) and 4095 (reserved) are not VLANs.
  let vlan = null;
  if ((etherType === ETHERTYPE_VLAN || etherType === ETHERTYPE_QINQ) && header.length >= l3 + 4) {
    const vid = header.readUInt16BE(l3) & 0x0fff;
    if (vid >= 1 && vid <= 4094) vlan = vid;
    etherType = header.readUInt16BE(l3 + 2);
    l3 += 4;
    // The inner tag of a QinQ frame: skipped, the outer (service) VLAN is kept.
    if (etherType === ETHERTYPE_VLAN && header.length >= l3 + 4) {
      etherType = header.readUInt16BE(l3 + 2);
      l3 += 4;
    }
  }

  const bytes = Number.isFinite(frameLength) && frameLength > 0 ? frameLength : header.length;
  const flow = { srcAddr: '0.0.0.0', dstAddr: '0.0.0.0', srcPort: 0, dstPort: 0, protocol: 0, bytes, packets: 1 };
  // Layer-2 metadata: the frame's own MAC addresses and VLAN. Addresses only,
  // never payload — the same class of data as the IP 5-tuple.
  flow.dstMac = mac(header, 0);
  flow.srcMac = mac(header, 6);
  if (vlan != null) flow.vlan = vlan;

  if (etherType === ETHERTYPE_IPV4) {
    if (header.length < l3 + 20) return null;
    const ihl = (header[l3] & 0x0f) * 4;
    flow.protocol = header[l3 + 9];
    flow.srcAddr = ipv4(header, l3 + 12);
    flow.dstAddr = ipv4(header, l3 + 16);
    const l4 = l3 + (ihl >= 20 ? ihl : 20);
    Object.assign(flow, readPorts(header, l4, flow.protocol, header.length));
  } else if (etherType === ETHERTYPE_IPV6) {
    if (header.length < l3 + 40) return null;
    flow.protocol = header[l3 + 6]; // next header (no extension-header walking)
    flow.srcAddr = ipv6(header, l3 + 8);
    flow.dstAddr = ipv6(header, l3 + 24);
    Object.assign(flow, readPorts(header, l3 + 40, flow.protocol, header.length));
  } else {
    return null; // not IP — nothing to aggregate by port/protocol
  }

  flow.protocolName = PROTO_NAMES[flow.protocol] || String(flow.protocol);
  return flow;
}

module.exports = { decodeSampledHeader, ETHERTYPE_IPV4, ETHERTYPE_IPV6 };
